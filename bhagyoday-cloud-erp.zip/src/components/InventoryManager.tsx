import React, { useState, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { 
  Package, 
  Upload, 
  Search, 
  Filter, 
  TriangleAlert, 
  History, 
  RefreshCcw, 
  ChevronDown,
  ChevronUp,
  Download,
  Plus,
  Trash2,
  CheckCircle2,
  FileSpreadsheet,
  CircleAlert,
  LayoutGrid,
  Settings
} from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, query, onSnapshot, orderBy, doc, deleteDoc, updateDoc, setDoc, limit } from 'firebase/firestore';
import { InventoryItem, DispatchLog, MaterialVariant } from '../types';
import { cn } from '../lib/utils';
import { getMaterialKey, resetAndUploadStock, updateLowStockThreshold } from '../lib/stockService';

/**
 * Manual Excel Parser replacement for AI Analysis
 */
const manualInventoryParser = (sheetData: Record<string, any[]>) => {
  const categories: any[] = [];
  
  Object.entries(sheetData).forEach(([sheetName, rows]) => {
    const ucName = sheetName.toUpperCase();
    if (ucName.includes('SCREW')) return; // Ignore screw sheet as per rules
    
    const products: any[] = [];
    
    if (ucName.includes('JSW')) {
      // Basic JSW parsing logic (Simplified for stability)
      // Expect headers: MAKE, GSM, THICKNESS, COLOUR, etc.
      const headers = rows[0] || [];
      const makeIdx = headers.indexOf('MAKE');
      const gsmIdx = headers.indexOf('GSM');
      const thickIdx = headers.indexOf('THICKNESS');
      const colorIdx = headers.indexOf('COLOUR');
      const totalIdx = headers.indexOf('TOTAL RFT');
      
      rows.slice(1).forEach(row => {
        if (row[makeIdx]) {
          products.push({
            productName: `${row[makeIdx]} ${row[colorIdx] || ''} ${row[thickIdx] || ''}`.trim(),
            brand: row[makeIdx],
            gsm: row[gsmIdx],
            thickness: row[thickIdx],
            colour: row[colorIdx],
            totalStock: Number(row[totalIdx]) || 0,
            unit: 'RFT',
            tableSource: 'JSW'
          });
        }
      });
    } else if (ucName.includes('UPVC')) {
      // UPVC Logic
      rows.slice(1).forEach(row => {
        if (row[0]) { // Assuming Brand is first
           products.push({
             productName: `${row[0]} ${row[1] || ''}`.trim(),
             brand: row[0],
             size: row[1],
             totalStock: Number(row[row.length - 1]) || 0, // Last col usually stock
             unit: 'PCS',
             tableSource: 'UPVC'
           });
        }
      });
    } else {
      // General fallback
      rows.slice(1).forEach(row => {
        if (row[0]) {
           products.push({
             productName: String(row[0]),
             totalStock: Number(row[1]) || 0,
             unit: 'UNIT',
             tableSource: sheetName
           });
        }
      });
    }
    
    if (products.length > 0) {
      categories.push({ categoryName: sheetName, products });
    }
  });
  
  return { categories };
};


const getMaterialColor = (colorName: string) => {
  const c = (colorName || '').toLowerCase();
  if (c.includes('red')) return 'bg-red-500';
  if (c.includes('blue')) return 'bg-blue-600';
  if (c.includes('green')) return 'bg-green-600';
  if (c.includes('grey') || c.includes('gray')) return 'bg-slate-500';
  if (c.includes('white')) return 'bg-slate-100 text-slate-900 border border-slate-200';
  if (c.includes('black')) return 'bg-slate-900';
  if (c.includes('orange')) return 'bg-orange-500';
  if (c.includes('yellow')) return 'bg-yellow-500';
  if (c.includes('brown')) return 'bg-amber-900';
  if (c.includes('silver')) return 'bg-slate-300 text-slate-700';
  if (c.includes('gold')) return 'bg-amber-500';
  return null;
};

const InventoryRow = React.memo(({ 
  item, 
  onDelete, 
  onUpdateLimit 
}: { 
  item: InventoryItem; 
  onDelete: (id: string) => void;
  onUpdateLimit: (id: string, limit: number, remaining: number) => void;
}) => {
  const isLow = item.status === 'LOW_STOCK';
  const isOut = item.status === 'OUT_OF_STOCK';
  const isJSW = (item.category || '').toUpperCase().includes('JSW');

  return (
    <tr className={cn("hover:bg-slate-50/80 transition-colors group", isLow && "bg-amber-50/20", isOut && "bg-red-50/20")}>
       <td className="px-8 py-5">
          <div className="flex items-center gap-4">
             <div className={cn(
               "w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg transition-transform group-hover:scale-110 shrink-0",
               isOut ? "bg-red-600 text-white" : isLow ? "bg-amber-500 text-white" : (getMaterialColor(item.colour || '') || "bg-slate-900 text-white")
             )}>
                <Package size={20} />
             </div>
             <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                   <p className="text-sm font-black text-slate-900 uppercase tracking-tight truncate">{item.productName}</p>
                   <span className="px-1.5 py-0.5 rounded-lg bg-slate-100 text-[8px] font-black text-slate-400 uppercase tracking-tighter shrink-0">
                     {item.brand || item.category}
                   </span>
                </div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest truncate">
                   Source: {item.sourceSheet} {item.thickness && `• ${item.thickness}`} {item.gsm && `• ${item.gsm}`}
                </p>
             </div>
          </div>
       </td>
       <td className="px-8 py-5 text-center">
          <p className={cn("text-base font-black leading-none", isOut ? "text-red-600" : isLow ? "text-amber-600" : "text-slate-900")}>
             {(item.remaining ?? 0).toLocaleString()} 
             <span className="text-[10px] ml-1 opacity-40 uppercase tracking-widest font-black shrink-0">{item.unit}</span>
          </p>
          
          {isJSW && (
            <div className="mt-2 flex items-center justify-center gap-2">
               <div className="flex flex-col items-center">
                  <span className="text-[8px] font-black text-slate-400 uppercase leading-none mb-1">Packed</span>
                  <span className="text-[10px] font-black text-slate-600 leading-none">{(item.packedCoilStock || 0).toLocaleString()}</span>
               </div>
               <div className="w-[1px] h-4 bg-slate-100" />
               <div className="flex flex-col items-center">
                  <span className="text-[8px] font-black text-blue-400 uppercase leading-none mb-1">Open</span>
                  <span className="text-[10px] font-black text-blue-600 leading-none">{(item.openCoilStock || 0).toLocaleString()}</span>
               </div>
            </div>
          )}

          <div className="w-24 h-1 bg-slate-100 rounded-full mx-auto mt-2 overflow-hidden">
             <div 
               className={cn("h-full", isOut ? "bg-red-500" : isLow ? "bg-amber-500" : "bg-green-500")}
               style={{ width: `${Math.min(100, (item.remaining / (item.stock || 1)) * 100)}%` }}
             />
          </div>
       </td>
       <td className="px-8 py-5 text-center">
          <div className={cn(
             "w-12 h-12 rounded-2xl mx-auto flex flex-col items-center justify-center border",
             (item.estimatedDaysLeft || 0) < 7 && item.remaining > 0 ? "bg-red-50 border-red-100 text-red-600" : "bg-slate-50 border-slate-100 text-slate-900"
          )}>
             <span className="text-[12px] font-black leading-tight">{item.estimatedDaysLeft && item.estimatedDaysLeft < 999 ? Math.round(item.estimatedDaysLeft) : '∞'}</span>
             <span className="text-[7px] font-black uppercase opacity-60">Days</span>
          </div>
       </td>
       <td className="px-8 py-5 text-center hidden md:table-cell">
          <div className="flex justify-center">
             <div className={cn(
               "px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border shadow-sm",
               isOut ? "bg-red-50 text-red-600 border-red-100" :
               isLow ? "bg-amber-50 text-amber-600 border-amber-100" :
               "bg-green-50 text-green-600 border-green-100"
             )}>
                {isOut ? 'Critical' : isLow ? 'Low Level' : 'Available'}
             </div>
          </div>
       </td>
       <td className="px-8 py-5">
          <div className="flex items-center justify-end gap-3 text-right">
             <div className="flex flex-col items-end">
                <label className="text-[7px] font-black text-slate-300 uppercase mb-1">Alert Qty</label>
                <input 
                  type="number" 
                  className="w-16 bg-slate-100 border border-slate-200 text-[10px] font-black h-8 rounded-xl text-center focus:ring-2 focus:ring-blue-500/20"
                  defaultValue={item.lowStockLimit || 500}
                  onBlur={(e) => {
                    const val = Number(e.target.value);
                    if (val !== item.lowStockLimit) {
                      onUpdateLimit(item.id!, val, item.remaining);
                    }
                  }}
                />
             </div>
             <button 
               onClick={() => onDelete(item.id!)}
               className="p-2.5 bg-slate-50 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100 active:scale-90"
             >
                <Trash2 size={16} />
             </button>
          </div>
       </td>
    </tr>
  );
});

const LogRow = React.memo(({ log }: { log: DispatchLog }) => (
  <tr className="hover:bg-slate-50/80 transition-colors">
      <td className="px-8 py-5 text-[10px] font-bold text-slate-500">
         {new Date(log.createdAt).toLocaleString()}
      </td>
      <td className="px-8 py-5">
         <span className="px-2 py-1 rounded-lg bg-blue-50 text-[9px] font-black text-blue-600 uppercase">
           {log.materialName?.split(' - ')[0] || 'Unknown'}
         </span>
      </td>
      <td className="px-8 py-5">
         <p className="text-[11px] font-black text-slate-900 uppercase truncate max-w-md">
            {log.materialName}
         </p>
      </td>
      <td className="px-8 py-5 text-center font-black text-red-600">
         - {(log.qtyDeducted || log.quantityUsedRFT || 0).toFixed(2)} RFT
      </td>
      <td className="px-8 py-5 text-right text-[9px] font-black text-slate-400 uppercase tracking-widest">
         {log.userName?.split('@')[0] || 'System'}
      </td>
  </tr>
));

export const InventoryManager: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'stock' | 'logs'>('stock');
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [logs, setLogs] = useState<DispatchLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [makeFilter, setMakeFilter] = useState('ALL');
  const [selectedCategory, setSelectedCategory] = useState('ALL');
  const [selectedProduct, setSelectedProduct] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [alertOpen, setAlertOpen] = useState(false);
  const [lastAlert, setLastAlert] = useState<InventoryItem | null>(null);
  // Report status
  const [reportDue, setReportDue] = useState(false);

  useEffect(() => {
    // Check if report is due (Simulation: every 3 days)
    const lastReport = localStorage.getItem('last_stock_report_ts');
    if (lastReport) {
       const days = (Date.now() - Number(lastReport)) / (1000 * 60 * 60 * 24);
       if (days >= 3) setReportDue(true);
    } else {
       setReportDue(true);
    }
    const qInv = query(collection(db, 'inventory'));
    const unsubInv = onSnapshot(qInv, (snap) => {
      const items = snap.docs.map(d => ({ ...d.data(), id: d.id } as InventoryItem));
      // Client-side sort by make and color
      const sortedItems = items.sort((a, b) => {
        if (a.make !== b.make) return a.make.localeCompare(b.make);
        return a.colour.localeCompare(b.colour);
      });
      setInventory(sortedItems);
      setLoading(false);

      // Check for low stock alerts (simple logic: find first item that just went low)
      const lowStockItem = items.find(it => it.remaining <= (it.lowStockLimit || 0) && it.remaining > 0);
      if (lowStockItem && !alertOpen) {
        setLastAlert(lowStockItem);
        setAlertOpen(true);
      }
    }, (error) => {
      console.error("Inventory Sync Error:", error);
    });

    const qLogs = query(collection(db, 'dispatch_logs'), orderBy('createdAt', 'desc'), limit(50));
    const unsubLogs = onSnapshot(qLogs, (snap) => {
      setLogs(snap.docs.map(d => ({ ...d.data(), id: d.id } as DispatchLog)));
    }, (error) => {
      console.error("Logs Sync Error:", error);
    });

    return () => {
      unsubInv();
      unsubLogs();
    };
  }, []);

  const resetFilters = () => {
    setSearchTerm('');
    setMakeFilter('ALL');
    setSelectedCategory('ALL');
    setSelectedProduct('ALL');
    setStatusFilter('ALL');
  };

  const deleteMaterial = async (id: string) => {
    if (confirm("Delete this material permanently?")) {
      try {
        await deleteDoc(doc(db, 'inventory', id));
      } catch (err) {
        console.error("Delete Error:", err);
      }
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setUploadProgress(10);
    const reader = new FileReader();

    reader.onload = async (evt) => {
      try {
        const dataBuffer = evt.target?.result as ArrayBuffer;
        const wb = XLSX.read(dataBuffer, { type: 'array' });
        
        const sheetData: Record<string, any[]> = {};
        wb.SheetNames.forEach(name => {
          const ws = wb.Sheets[name];
          sheetData[name] = XLSX.utils.sheet_to_json(ws, { header: 1 });
        });

        setUploadProgress(30);
        
        // Manual Parsing (Replacing AI for performance & cost)
        const aiResponse = manualInventoryParser(sheetData);
        
        setUploadProgress(70);

        if (!aiResponse || !aiResponse.categories) {
          throw new Error("AI analysis failed to interpret the file structure.");
        }

        const now = new Date().toISOString();
        const allItems: InventoryItem[] = [];

        aiResponse.categories.forEach(cat => {
          cat.products.forEach(p => {
            const lowLimit = cat.categoryName.toUpperCase().includes('JSW') || cat.categoryName.toUpperCase().includes('ROOFING') ? 500 : 50;
            
            allItems.push({
              category: cat.categoryName || 'GENERAL',
              productName: p.productName,
              brand: p.brand || '',
              size: p.size || '',
              make: p.brand || 'GENERAL', // Map brand to make for compatibility
              colour: p.colour || 'VARIOUS',
              thickness: p.thickness || '-',
              gsm: p.gsm || '-',
              stock: p.totalStock || p.stock || 0,
              packedCoilStock: p.packedCoilStock || 0,
              openCoilStock: p.openCoilStock || 0,
              used: 0,
              remaining: p.totalStock || p.stock || 0,
              unit: p.unit || 'UNIT',
              status: ((p.totalStock || p.stock || 0) <= 0) ? 'OUT_OF_STOCK' : ((p.totalStock || p.stock || 0) <= lowLimit) ? 'LOW_STOCK' : 'IN_STOCK',
              lowStockLimit: lowLimit,
              sourceSheet: p.tableSource || cat.categoryName,
              dispatchFrom: p.dispatchFrom || 'stock',
              createdAt: now,
              updatedAt: now
            });
          });
        });

        if (allItems.length === 0) {
          alert("AI Analysis: No valid products detected in this file.");
          setUploading(false);
          return;
        }

        setUploadProgress(90);
        await resetAndUploadStock(allItems);
        setUploadProgress(100);
        
        setTimeout(() => {
          setUploading(false);
          setUploadProgress(0);
          
          const totalSheets = aiResponse.categories.length;
          let alertMsg = `AI Analysis Complete: Successfully processed ${totalSheets} categories and imported ${allItems.length} items.`;
          alert(alertMsg);
        }, 500);

      } catch (err) {
        console.error("AI Inventory Engine Error:", err);
        alert("AI Parser Error: " + (err instanceof Error ? err.message : String(err)));
        setUploading(false);
        setUploadProgress(0);
      }
    };
    reader.readAsArrayBuffer(file);
  };


  const filteredInventory = React.useMemo(() => {
    return inventory.filter(it => {
      const searchStr = `${it.productName} ${it.category} ${it.sourceSheet}`.toLowerCase();
      const matchesSearch = searchStr.includes(searchTerm.toLowerCase());
      const matchesMake = makeFilter === 'ALL' || it.make === makeFilter;
      const matchesCategory = selectedCategory === 'ALL' || it.category === selectedCategory;
      const matchesProduct = selectedProduct === 'ALL' || it.colour === selectedProduct;
      
      let matchesStatus = true;
      if (statusFilter === 'LOW') matchesStatus = it.status === 'LOW_STOCK';
      if (statusFilter === 'OUT') matchesStatus = it.status === 'OUT_OF_STOCK';
      if (statusFilter === 'IN') matchesStatus = it.status === 'IN_STOCK';

      return matchesSearch && matchesMake && matchesCategory && matchesProduct && matchesStatus;
    });
  }, [inventory, searchTerm, makeFilter, selectedCategory, selectedProduct, statusFilter]);

  const categories = React.useMemo(() => 
    Array.from(new Set(inventory.map(it => it.category))).sort(), 
    [inventory]
  );

  const currentSheetVariants = React.useMemo(() => {
    if (selectedCategory === 'ALL') return [];
    return Array.from(new Set(
      inventory.filter(it => it.category === selectedCategory).map(it => it.colour)
    )).sort();
  }, [inventory, selectedCategory]);

  const generateReport = () => {
    const headers = ["Product Name", "Category", "Sheet", "Source Stock", "Consumed", "Current Balance", "Unit", "Status"];
    const rows = inventory.map(it => [
      it.productName,
      it.category,
      it.sourceSheet,
      it.stock,
      it.used || 0,
      it.remaining,
      it.unit,
      it.status
    ]);

    const ws = XLSX.utils.aoa_to_sheet([headers, ...rows]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Master Stock Report");
    XLSX.writeFile(wb, `Inventory_Intelligence_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
    localStorage.setItem('last_stock_report_ts', Date.now().toString());
    setReportDue(false);
  };

  const lowStockItems = React.useMemo(() => inventory.filter(i => i.status === 'LOW_STOCK'), [inventory]);
  const outOfStockItems = React.useMemo(() => inventory.filter(i => i.status === 'OUT_OF_STOCK'), [inventory]);
  const healthyItemsCount = inventory.length - lowStockItems.length - outOfStockItems.length;

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
        <div>
           <h1 className="text-2xl font-black text-slate-900 uppercase tracking-tight">Inventory</h1>
           <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Track material stock and usage</p>
        </div>
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
           <label 
             id="upload-stock-label"
             className={cn(
               "flex-1 md:flex-none flex items-center justify-center gap-3 px-8 py-4 bg-blue-600 text-white rounded-2xl text-[11px] font-black uppercase tracking-[0.1em] cursor-pointer hover:bg-blue-700 transition-all shadow-xl shadow-blue-100 active:scale-95 group",
               uploading && "opacity-50 cursor-not-allowed"
             )}
           >
              {uploading ? (
                <RefreshCcw size={16} className="animate-spin" />
              ) : (
                <Upload size={16} className="group-hover:scale-110 transition-transform" />
              )}
              <span>{uploading ? 'Processing File...' : 'Import Stock (Multi-Sheet)'}</span>
              <input type="file" accept=".xlsx, .xls" className="hidden" onChange={handleFileUpload} disabled={uploading} />
           </label>
           <button 
             onClick={async () => {
               if (confirm("DELETE ALL INVENTORY DATA? This cannot be undone.")) {
                 setUploading(true);
                 try {
                   await resetAndUploadStock([]);
                   // Success silently updates via onSnapshot
                 } catch (err) {
                   console.error(err);
                 } finally {
                   setUploading(false);
                 }
               }
             }}
             disabled={uploading}
             className={cn(
                "flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-white border border-red-200 text-red-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-50 transition-all shadow-sm",
                uploading && "opacity-50"
             )}
           >
              {uploading ? <RefreshCcw size={14} className="animate-spin" /> : <Trash2 size={14} />}
              Clear All Data
           </button>
           <button 
             onClick={generateReport}
             className="flex-1 md:flex-none flex items-center justify-center gap-2 px-6 py-3 bg-white border border-slate-200 text-slate-900 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-50 transition-all shadow-sm"
           >
              <Download size={14} />
              Download Report
           </button>
        </div>
      </header>

      {uploading && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-3">
          <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-slate-400">
            <span>Processing Stock Data...</span>
            <span>{uploadProgress}%</span>
          </div>
          <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
             <div 
               className="h-full bg-blue-500 transition-all duration-300"
               style={{ width: `${uploadProgress}%` }}
             ></div>
          </div>
        </div>
      )}

      {reportDue && (
        <div className="bg-blue-900 text-white p-4 rounded-2xl flex items-center justify-between shadow-xl shadow-blue-100 animate-in fade-in slide-in-from-top-4 duration-500">
           <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-blue-300">
                 <FileSpreadsheet size={20} />
              </div>
              <div>
                 <p className="text-[11px] font-black uppercase tracking-tight">Stock Analysis Report Ready</p>
                 <p className="text-[9px] text-blue-200 font-bold uppercase tracking-widest">3-day threshold for physical verification reached</p>
              </div>
           </div>
           <button 
             onClick={generateReport}
             className="px-6 py-2 bg-white text-blue-900 rounded-lg text-[10px] font-black uppercase tracking-widest hover:bg-blue-50 transition-all active:scale-95"
           >
              Download Report
           </button>
        </div>
      )}

      {/* Inventory Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
         {[
           { label: 'Total Items', value: inventory.length, sub: 'All Categories', icon: Package, color: 'text-blue-600', bg: 'bg-blue-50' },
           { label: 'Low Stock', value: lowStockItems.length, sub: 'Needs Attention', icon: TriangleAlert, color: 'text-amber-600', bg: 'bg-amber-50' },
           { label: 'Out of Stock', value: outOfStockItems.length, sub: 'Zero Inventory', icon: CircleAlert, color: 'text-red-600', bg: 'bg-red-50' },
           { label: 'Categories', value: categories.length, sub: 'Excel Sheets', icon: FileSpreadsheet, color: 'text-purple-600', bg: 'bg-purple-50' },
         ].map((stat) => (
           <div key={`stat-${stat.label}`} className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm flex items-center gap-4">
              <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center shrink-0", stat.bg, stat.color)}>
                 <stat.icon size={22} />
              </div>
              <div>
                 <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest">{stat.label}</p>
                 <div className="flex items-baseline gap-1">
                    <span className="text-lg font-black text-slate-900">{stat.value}</span>
                    <span className="text-[8px] font-bold text-slate-400 uppercase">{stat.sub}</span>
                 </div>
              </div>
           </div>
         ))}
      </div>

      {/* Main Layout: Sidebar and Content */}
      <div className="flex flex-col lg:flex-row gap-8">
          {/* Vertical Sidebar */}
          <aside className="w-full lg:w-64 shrink-0 space-y-6">
           {/* Tabs and Sidebar Content */}
           <div className="bg-slate-100 p-1.5 rounded-2xl flex flex-row lg:flex-col gap-1 overflow-x-auto lg:overflow-x-visible no-scrollbar">
                  {[
                    { id: 'stock', label: 'Inventory', icon: Package },
                    { id: 'logs', label: 'Usage Logs', icon: History }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={cn(
                        "px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all flex items-center gap-3 whitespace-nowrap flex-1 lg:flex-none",
                        activeTab === tab.id ? "bg-white text-slate-900 shadow-xl" : "text-slate-500 hover:bg-slate-200"
                      )}
                    >
                      <tab.icon size={14} />
                      {tab.label}
                    </button>
                  ))}
              </div>

              {/* Unified Sidebar Navigation */}
              <div className="space-y-6">
                  <div className="space-y-3">
                      <div className="flex items-center justify-between px-4">
                          <h4 className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400">Inventory Sheets</h4>
                          <span className="text-[8px] font-black text-slate-300 uppercase">{categories.length}</span>
                      </div>
                      <div className="bg-white p-2 rounded-3xl border border-slate-200 flex flex-col gap-1">
                          <button 
                            onClick={() => {
                              setSelectedCategory('ALL');
                              setSelectedProduct('ALL');
                            }}
                            className={cn(
                              "px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all text-left flex items-center gap-3",
                              selectedCategory === 'ALL' ? "bg-slate-900 text-white shadow-xl" : "text-slate-500 hover:bg-slate-50"
                            )}
                          >
                               <div className="flex items-center gap-3 flex-1">
                                  <LayoutGrid size={14} className="shrink-0" />
                                  <span>All Sheets & Products</span>
                               </div>
                               <span className="text-[8px] opacity-40">{inventory.length}</span>
                          </button>

                          <div className="h-[1px] bg-slate-50 my-1 mx-2" />

                          {categories.map(cat => {
                            const isSelected = selectedCategory === cat;
                            const itemsInCat = inventory.filter(i => i.category === cat);
                            
                            return (
                              <div key={cat} className="space-y-1">
                                <button 
                                  onClick={() => {
                                    setSelectedCategory(cat);
                                    setSelectedProduct('ALL');
                                  }}
                                  className={cn(
                                    "w-full px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all text-left flex items-center gap-3",
                                    isSelected ? "bg-blue-600 text-white shadow-lg" : "text-slate-500 hover:bg-slate-50"
                                  )}
                                >
                                    <div className="flex items-center gap-3 flex-1 min-w-0">
                                       <FileSpreadsheet size={14} className="shrink-0" />
                                       <span className="truncate">{cat}</span>
                                    </div>
                                    <span className={cn("text-[8px]", isSelected ? "text-white/60" : "opacity-40")}>
                                      {itemsInCat.length}
                                    </span>
                                </button>

                                {isSelected && currentSheetVariants.length > 0 && (
                                  <div className="mt-1 ml-4 pl-4 border-l-2 border-blue-50 space-y-1 animate-in fade-in slide-in-from-left-2 duration-300">
                                    <button 
                                      onClick={() => setSelectedProduct('ALL')}
                                      className={cn(
                                        "w-full px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest text-left transition-all",
                                        selectedProduct === 'ALL' ? "text-blue-600 bg-blue-50/50" : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
                                      )}
                                    >
                                      • All Variants
                                    </button>
                                    {currentSheetVariants.map(variant => (
                                      <button 
                                        key={variant}
                                        onClick={() => setSelectedProduct(variant)}
                                        className={cn(
                                          "w-full px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest text-left transition-all",
                                          selectedProduct === variant ? "text-blue-600 bg-blue-50" : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
                                        )}
                                      >
                                        • {variant}
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                      </div>
                  </div>
              </div>

              {/* Health Quick Filter */}
              <div className="space-y-3 hidden lg:block">
                  <h4 className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-400 px-4">Stock Health</h4>
                  <div className="grid grid-cols-1 gap-2">
                      {[
                        { id: 'LOW', label: 'Low Stock', color: 'bg-amber-500' },
                        { id: 'OUT', label: 'Out of Stock', color: 'bg-red-600' },
                        { id: 'IN', label: 'Healthy', color: 'bg-green-600' },
                        { id: 'ALL', label: 'Clear Filter', color: 'bg-slate-500' }
                      ].map(status => (
                        <button
                          key={status.id}
                          onClick={() => setStatusFilter(status.id)}
                          className={cn(
                            "px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-between group transition-all",
                            statusFilter === status.id ? "bg-slate-900 text-white" : "bg-slate-50 text-slate-500 hover:bg-slate-200"
                          )}
                        >
                           <div className="flex items-center gap-3">
                              <div className={cn("w-2 h-2 rounded-full", status.color)} />
                              {status.label}
                           </div>
                           <span className="opacity-40 text-[9px]">
                             {status.id === 'ALL' ? inventory.length : 
                               status.id === 'LOW' ? inventory.filter(i => i.status === 'LOW_STOCK').length :
                               status.id === 'OUT' ? inventory.filter(i => i.status === 'OUT_OF_STOCK').length :
                               inventory.filter(i => i.status === 'IN_STOCK').length}
                           </span>
                        </button>
                      ))}
                  </div>
              </div>
          </aside>

          {/* Main Content Area */}
          <main className="flex-1 min-w-0 space-y-6">
              {activeTab === 'stock' && (
                <>
                <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row gap-4 items-center">
                    <div className="relative flex-1 w-full">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-300" size={16} />
                        <input 
                          placeholder="Search across all categories..."
                          className="w-full pl-10 h-11 bg-slate-50 border-none text-[10px] font-black uppercase tracking-widest rounded-xl focus:ring-2 focus:ring-blue-500/20 transition-all placeholder:text-slate-300"
                          value={searchTerm}
                          onChange={e => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <select 
                      className="w-full md:w-56 h-11 bg-slate-50 border-none text-[9px] font-black uppercase tracking-widest rounded-xl px-4 cursor-pointer"
                      value={makeFilter}
                      onChange={e => setMakeFilter(e.target.value)}
                    >
                        <option value="ALL">All Manufacturers ▼</option>
                        {Array.from(new Set(inventory.map(it => it.make))).sort().map(m => <option key={m} value={m}>{m}</option>)}
                    </select>

                    <button 
                      onClick={resetFilters}
                      className="h-11 px-6 bg-slate-100 text-slate-500 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all flex items-center gap-2"
                      title="Reset all filters"
                    >
                      <RefreshCcw size={12} />
                      Reset Filters
                    </button>
                </div>

                <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-xl shadow-slate-100 overflow-hidden">
                    <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                            <thead>
                               <tr className="bg-slate-50/50 border-b border-slate-100 text-[10px] font-black uppercase tracking-widest text-slate-400">
                                   <th className="px-8 py-5">Material Description</th>
                                   <th className="px-8 py-5 text-center">Remaining</th>
                                   <th className="px-8 py-5 text-center">Stock Days</th>
                                   <th className="px-8 py-5 text-center">Status</th>
                                   <th className="px-8 py-5 text-right">Settings</th>
                               </tr>
                             </thead>
                             <tbody className="divide-y divide-slate-50">
                                {filteredInventory.map((item) => (
                                    <InventoryRow 
                                      key={item.id} 
                                      item={item} 
                                      onDelete={deleteMaterial}
                                      onUpdateLimit={async (id, limit, remaining) => {
                                        const status = remaining <= 0 ? 'OUT_OF_STOCK' : remaining <= limit ? 'LOW_STOCK' : 'IN_STOCK';
                                        await updateDoc(doc(db, 'inventory', id), { lowStockLimit: limit, status });
                                      }}
                                    />
                                ))}
                             </tbody>
                        </table>
                        {filteredInventory.length === 0 && (
                          <div className="py-24 text-center">
                             <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                                <Search className="text-slate-200" size={32} />
                             </div>
                             <h3 className="text-lg font-black text-slate-900 uppercase tracking-tight mb-2">No results found</h3>
                             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest max-w-xs mx-auto">
                                Adjust your filters or category selection to find what you're looking for.
                             </p>
                          </div>
                        )}
                    </div>
                </div>
                </>
              )}

              {activeTab === 'logs' && (
                <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
                   <div className="overflow-x-auto">
                      <table className="w-full text-left">
                         <thead>
                            <tr className="bg-slate-50/50 border-b border-slate-100 text-[10px] font-black uppercase tracking-widest text-slate-400">
                               <th className="px-8 py-5">Timestamp</th>
                               <th className="px-8 py-5">Category</th>
                               <th className="px-8 py-5">Material Variant</th>
                               <th className="px-8 py-5 text-center">Qty Deduct</th>
                               <th className="px-8 py-5 text-right">User ID</th>
                            </tr>
                         </thead>
                         <tbody className="divide-y divide-slate-50">
                            {logs.map(log => (
                               <LogRow key={log.id || `log-${log.createdAt}`} log={log} />
                            ))}
                         </tbody>
                      </table>
                   </div>
                </div>
              )}
          </main>
      </div>

      {/* Fixed Persistent Stock Alert Button (Bottom Left) */}
      <div className="fixed bottom-6 left-6 z-[60] group">
          <div className="relative">
              <div className={cn(
                "w-12 h-12 rounded-2xl shadow-2xl flex items-center justify-center cursor-pointer transition-all active:scale-95",
                outOfStockItems.length > 0 ? "bg-red-600 animate-pulse" :
                lowStockItems.length > 0 ? "bg-amber-500" : "bg-slate-900"
              )}
                onClick={() => setAlertOpen(true)}
              >
                  <TriangleAlert className="text-white" size={20} />
                  {(lowStockItems.length + outOfStockItems.length > 0) && (
                    <span className="absolute -top-2 -right-2 bg-white text-slate-900 text-[8px] font-black px-1.5 py-0.5 rounded-full border-2 border-slate-900 shadow-md">
                      {lowStockItems.length + outOfStockItems.length}
                    </span>
                  )}
              </div>
              
              <div className="absolute bottom-full left-0 mb-4 scale-0 group-hover:scale-100 transition-all origin-bottom-left w-64 bg-slate-900 text-white p-4 rounded-2xl shadow-2xl space-y-3 pointer-events-none">
                  <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-400 border-b border-white/10 pb-2">Real-time Stock Monitor</h4>
                  <div className="space-y-2">
                      <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-red-400 uppercase">Out of Stock</span>
                          <span className="text-xs font-black">{outOfStockItems.length}</span>
                      </div>
                      <div className="flex justify-between items-center">
                          <span className="text-[10px] font-bold text-amber-400 uppercase">Low Stock</span>
                          <span className="text-xs font-black">{lowStockItems.length}</span>
                      </div>
                  </div>
                  <p className="text-[8px] text-slate-500 font-bold uppercase py-1">Click icon to view details</p>
              </div>
          </div>
      </div>
      {/* Low Stock Alert Detailed Modal */}
      {alertOpen && (
         <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="w-full max-w-lg bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[85vh]">
               <div className="p-8 pb-4 border-b border-slate-50">
                  <div className="flex justify-between items-start">
                     <div>
                        <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight">Stock Analysis</h2>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Found {lowStockItems.length + outOfStockItems.length} critical items</p>
                     </div>
                     <button 
                       onClick={() => setAlertOpen(false)}
                       className="p-2 hover:bg-slate-100 rounded-xl transition-colors text-slate-400"
                     >
                        <ChevronDown size={24} />
                     </button>
                  </div>
               </div>

               <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar custom-scrollbar">
                  {outOfStockItems.map(item => (
                    <div key={`modal-out-${item.id}`} className="p-4 bg-red-50 rounded-2xl border border-red-100 flex items-center justify-between group">
                       <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-red-600 rounded-xl flex items-center justify-center text-white shadow-lg">
                             <CircleAlert size={18} />
                          </div>
                          <div>
                             <p className="text-[10px] font-black text-red-900 uppercase">{item.category}</p>
                             <p className="text-xs font-black text-slate-900 uppercase tracking-tight">{item.productName}</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-xs font-black text-red-600 uppercase">Out of Stock</p>
                          <p className="text-[9px] font-bold text-red-400 uppercase">0.00 {item.unit} Remaining</p>
                       </div>
                    </div>
                  ))}

                  {lowStockItems.map(item => (
                    <div key={`modal-low-${item.id}`} className="p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-center justify-between">
                       <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-amber-500 rounded-xl flex items-center justify-center text-white shadow-lg">
                             <TriangleAlert size={18} />
                          </div>
                          <div>
                             <p className="text-[10px] font-black text-amber-900 uppercase">{item.category}</p>
                             <p className="text-xs font-black text-slate-900 uppercase tracking-tight">{item.productName}</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-xs font-black text-amber-600 uppercase">Low Stock</p>
                          <p className="text-[9px] font-bold text-amber-400 uppercase">{Math.round(item.remaining)} {item.unit} Left</p>
                       </div>
                    </div>
                  ))}

                  {(lowStockItems.length + outOfStockItems.length) === 0 && (
                    <div className="py-12 text-center">
                       <CheckCircle2 className="mx-auto text-green-500 opacity-20 mb-4" size={64} strokeWidth={1} />
                       <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest">All stock levels are healthy</p>
                    </div>
                  )}
               </div>

               <div className="p-6 bg-slate-50 border-t border-slate-100">
                  <button 
                    onClick={() => setAlertOpen(false)}
                    className="w-full py-4 bg-slate-900 text-white rounded-xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-slate-200 active:scale-95 transition-all"
                  >
                     Close Analysis Report
                  </button>
               </div>
            </div>
         </div>
      )}
    </div>
  );
};
