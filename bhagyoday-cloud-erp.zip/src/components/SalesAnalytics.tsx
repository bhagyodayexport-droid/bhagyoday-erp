import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot } from 'firebase/firestore';
import { Quotation, UserProfile } from '../types';
import { TrendingUp, Users, ShoppingBag, IndianRupee, ArrowUpRight, ArrowDownRight, Clock, CheckCircle2, BarChart3 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const MaterialStatRow = React.memo(({ name, stat, index }: { name: string, stat: any, index: number }) => (
  <div className="p-6 bg-slate-50/50 rounded-2xl border border-transparent hover:border-slate-200 hover:bg-white transition-all flex items-center justify-between group">
     <div className="flex items-center gap-4">
        <div className="w-8 h-8 bg-white border border-slate-200 rounded-xl flex items-center justify-center font-black text-xs text-slate-400">#{index+1}</div>
        <div>
           <p className="text-xs font-black text-slate-900 uppercase">{name}</p>
           <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Sold: {Math.round(stat.qty)} RFT/SQ</p>
        </div>
     </div>
     <div className="text-right">
        <p className="text-lg font-black text-slate-900 leading-none mb-1">₹{Math.round(stat.revenue/1000)}k</p>
        <div className="text-[9px] font-black text-green-600 uppercase tracking-widest">₹{Math.round(stat.profit/1000)}k Profit</div>
     </div>
  </div>
));

const CustomerStatCard = React.memo(({ name, stat, totalRev }: { name: string, stat: any, totalRev: number }) => (
  <div className="p-8 rounded-3xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/10 transition-all group relative">
     <div className="flex justify-between items-start mb-6">
        <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-slate-900 border border-slate-100 shadow-sm font-black text-lg">
           {name.charAt(0)}
        </div>
        <div className="text-xs font-black text-blue-600 bg-blue-100 px-3 py-1 rounded-full uppercase tracking-widest">
           {stat.count} Orders
        </div>
     </div>
     <h3 className="text-lg font-black text-slate-900 uppercase mb-2 truncate max-w-full">{name}</h3>
     <div className="flex justify-between items-end mt-4">
        <div>
           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Revenue Shared</p>
           <p className="text-2xl font-black text-slate-900">₹{Math.round(stat.revenue).toLocaleString()}</p>
        </div>
        <div className="text-right pb-1">
           <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Market Share</div>
           <div className="text-xs font-black text-blue-500">{totalRev > 0 ? ((stat.revenue/totalRev)*100).toFixed(1) : 0}%</div>
        </div>
     </div>
  </div>
));

const EmployeeIntelligenceRow = React.memo(({ emp }: { emp: any }) => (
  <tr className="hover:bg-slate-50 transition-colors group">
      <td className="px-6 py-5">
         <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-9 h-9 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black text-xs">
                 {emp.email.charAt(0).toUpperCase()}
              </div>
              {emp.isOnline && <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>}
            </div>
            <div>
               <p className="text-xs font-black text-slate-900 uppercase tracking-tight">{emp.email.split('@')[0]}</p>
               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{emp.role}</p>
            </div>
         </div>
      </td>
      <td className="px-6 py-5 text-center">
         <span className="text-xs font-black text-slate-900" title="Total">{emp.stats.total}</span>
         <span className="text-[10px] font-bold text-green-600" title="Success"> / {emp.stats.approved}</span>
         <span className="text-[10px] font-bold text-amber-600" title="Negotiations"> / {emp.stats.negotiations}</span>
      </td>
    <td className="px-6 py-5">
       <div className="max-w-[100px] mx-auto space-y-1 text-center">
          <span className="text-[10px] font-black text-blue-600">{emp.stats.conversion.toFixed(1)}%</span>
          <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
             <div 
               className="h-full bg-blue-600 transition-all duration-500" 
               style={{ width: `${emp.stats.conversion}%` }}
             ></div>
          </div>
       </div>
    </td>
    <td className="px-6 py-5 text-center font-black text-slate-900 text-sm">₹{Math.round(emp.stats.revenue/1000)}k</td>
    <td className="px-6 py-5 text-right font-bold text-slate-400 text-[10px] uppercase tracking-tighter shrink-0">
       {emp.lastSeen ? new Date(emp.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '---'}
    </td>
 </tr>
));

export const SalesAnalytics: React.FC = () => {
  const { profile } = useAuth();
  const [data, setData] = useState<Quotation[]>([]);
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);

  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM

  useEffect(() => {
    const q = query(collection(db, 'quotations'), orderBy('createdAt', 'desc'));
    const unsubQuotes = onSnapshot(q, (snap) => {
      setData(snap.docs.map(d => ({ ...d.data(), id: d.id } as Quotation)));
      setLoading(false);
    });

    const uQuery = query(collection(db, 'users'), orderBy('lastSeen', 'desc'));
    const unsubUsers = onSnapshot(uQuery, (snap) => {
      setUsers(snap.docs.map(d => d.data() as UserProfile));
    });

    return () => {
      unsubQuotes();
      unsubUsers();
    };
  }, []);

  const {
    totalRev,
    totalProfit,
    avgQuote,
    topMaterials,
    topCustomers,
    employeeIntelligence,
    productStats,
    filteredData
  } = React.useMemo(() => {
    const filtered = data.filter(q => q.rawDate.startsWith(selectedMonth));
    const rev = filtered.reduce((acc, q) => acc + Number((q.grandTotal || 0).toString().replace(/,/g, '')), 0);
    const profit = filtered.reduce((acc, q) => acc + (q.totalProfit || 0), 0);
    const avg = filtered.length > 0 ? rev / filtered.length : 0;

    const mStats: Record<string, any> = {};
    const pStats: Record<string, any> = {};
    const cStats: Record<string, any> = {};

    filtered.forEach(q => {
      // Customer Stats
      if (!cStats[q.custName]) cStats[q.custName] = { revenue: 0, count: 0 };
      cStats[q.custName].revenue += Number((q.grandTotal || 0).toString().replace(/,/g, ''));
      cStats[q.custName].count += 1;

      q.items.forEach(item => {
        // Material Stats
        const mKey = `${item.make || 'Generic'} - ${item.colour || ''}`;
        if (!mStats[mKey]) mStats[mKey] = { qty: 0, revenue: 0, profit: 0, count: 0 };
        mStats[mKey].qty += Number(item.qty) || 0;
        mStats[mKey].revenue += Number(item.total) || 0;
        mStats[mKey].count += 1;
        if (item.costPrice) {
           mStats[mKey].profit += ((item.convertedRate || item.rate) - item.costPrice) * item.qty;
        }

        // Product Summary Stats
        if (!pStats[item.name]) pStats[item.name] = { qty: 0, length: 0, revenue: 0, count: 0 };
        pStats[item.name].qty += Number(item.qty) || 0;
        pStats[item.name].length += (Number(item.len) || 0) * (Number(item.pcs) || 0);
        pStats[item.name].revenue += Number(item.total) || 0;
        pStats[item.name].count += 1;
      });
    });

    const intel = users.map(user => {
      const userQuotes = filtered.filter(q => q.createdBy === user.uid);
      const approved = userQuotes.filter(q => q.status === 'Approved' || q.status === 'Material Dispatched').length;
      const negotiations = userQuotes.filter(q => q.status === 'Negotiation').length;
      const revenue = userQuotes.reduce((acc, q) => acc + Number((q.grandTotal || 0).toString().replace(/,/g, '')), 0);
      const isOnline = user.lastSeen ? (Date.now() - new Date(user.lastSeen).getTime() < 300000) : false;

      return { ...user, stats: { total: userQuotes.length, approved, negotiations, revenue, conversion: userQuotes.length > 0 ? (approved / userQuotes.length) * 100 : 0 }, isOnline };
    });

    return {
      totalRev: rev,
      totalProfit: profit,
      avgQuote: avg,
      topMaterials: Object.entries(mStats).sort((a,b) => b[1].revenue - a[1].revenue).slice(0, 3),
      topCustomers: Object.entries(cStats).sort((a,b) => b[1].revenue - a[1].revenue).slice(0, 3),
      employeeIntelligence: intel,
      productStats: pStats,
      filteredData: filtered
    };
  }, [data, users, selectedMonth]);

  const stats = [
    { label: 'Monthly Revenue', value: `₹${Math.round(totalRev/1000)}K`, icon: IndianRupee, change: 'Gross Sales', up: true },
    { label: 'Monthly Profit', value: `₹${Math.round(totalProfit/1000)}K`, icon: TrendingUp, change: `${totalRev > 0 ? ((totalProfit/totalRev)*100).toFixed(1) : 0}% Margin`, up: true },
    { label: 'Quotations Made', value: filteredData.length, icon: ShoppingBag, change: 'This Month', up: true },
    { label: 'Average Value', value: `₹${Math.round(avgQuote/1000)}K`, icon: CheckCircle2, change: 'Per Quotation', up: false },
  ];

  if (loading) return <div className="p-12 text-center text-[10px] font-black tracking-widest uppercase text-slate-400">Calculating Performance...</div>;

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-sm">
         <div>
            <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3">
              <BarChart3 size={24} className="text-blue-600" />
              Sales Overview
            </h2>
            <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest mt-1">Review your business performance</p>
         </div>
         <div className="w-full md:w-auto">
            <input 
              type="month" 
              className="w-full md:w-auto h-12 px-6 bg-slate-50 border-none rounded-xl text-xs font-black uppercase tracking-widest cursor-pointer focus:ring-2 focus:ring-blue-500/20 transition-all"
              value={selectedMonth}
              onChange={e => setSelectedMonth(e.target.value)}
            />
         </div>
      </div>

      {/* Primary Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((s) => (
          <div key={s.label} className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-xl shadow-slate-100 flex flex-col justify-between relative overflow-hidden group hover:scale-[1.02] transition-all duration-300">
             <div className="absolute -top-4 -right-4 w-24 h-24 bg-slate-50 rounded-full group-hover:scale-150 transition-transform duration-500 opacity-50"></div>
             
             <div className="relative z-10">
                <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-white mb-6 shadow-lg shadow-slate-200">
                   <s.icon size={22} />
                </div>
                <h3 className="text-4xl font-black text-slate-900 mb-2 leading-none">{s.value}</h3>
                <p className="text-[12px] font-black text-slate-400 uppercase tracking-widest">{s.label}</p>
             </div>
             
             <div className="mt-6 pt-4 border-t border-slate-100 relative z-10">
                <div className={cn(
                  "flex items-center gap-2 text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-lg w-fit",
                  s.up ? "text-green-600 bg-green-50" : "text-amber-600 bg-amber-50"
                )}>
                   {s.up ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
                   {s.change}
                </div>
             </div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
         {/* Top Materials - Boss View */}
         <div className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-xl shadow-slate-100">
            <div className="p-8 border-b border-slate-50 bg-slate-50/30">
               <h2 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                 🏆 Best Selling Materials
               </h2>
            </div>
            <div className="p-4 space-y-4">
               {topMaterials.map(([name, stat], i) => (
                  <MaterialStatRow key={name} name={name} stat={stat} index={i} />
               ))}
               {topMaterials.length === 0 && (
                 <div className="py-12 text-center text-[10px] font-black text-slate-300 uppercase tracking-widest">No Sales Data</div>
               )}
            </div>
         </div>

         {/* Top Customers - Boss View */}
         <div className="bg-white rounded-[2.5rem] border border-slate-200 overflow-hidden shadow-xl shadow-slate-100 lg:col-span-2">
            <div className="p-8 border-b border-slate-50 bg-slate-50/30">
               <h2 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center gap-2">
                 ⭐ Top Clients this Month
               </h2>
            </div>
            <div className="grid sm:grid-cols-2 gap-4 p-4">
               {topCustomers.map(([name, stat]) => (
                  <CustomerStatCard key={name} name={name} stat={stat} totalRev={totalRev} />
               ))}
               {topCustomers.length === 0 && (
                 <div className="col-span-2 py-12 text-center text-[10px] font-black text-slate-300 uppercase tracking-widest">No Client Data</div>
               )}
            </div>
         </div>
      </div>

      {/* Employee Sales Intelligence Tracker (Admin Only) */}
      {profile?.role === 'admin' && (
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
           <div className="p-6 border-b border-slate-50 flex justify-between items-center bg-slate-50/30">
              <div>
                <h2 className="text-sm font-black text-slate-900 uppercase tracking-tight">Productivity Tracker</h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">Real-time Activity & Conversion</p>
              </div>
              <div className="flex gap-4">
                 <div className="flex items-center gap-1.5 text-[9px] font-black text-green-600 uppercase tracking-widest">
                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                    Active
                 </div>
                 <div className="flex items-center gap-1.5 text-[9px] font-black text-slate-400 uppercase tracking-widest">
                    <div className="w-2 h-2 rounded-full bg-slate-200"></div>
                    Offline
                 </div>
              </div>
           </div>
           <div className="overflow-x-auto">
              <table className="w-full text-left">
                 <thead>
                    <tr className="bg-slate-50/50 text-[10px] font-black uppercase tracking-widest text-slate-500">
                       <th className="px-6 py-4">Employee</th>
                       <th className="px-6 py-4 text-center">Stats (Q/S/N)</th>
                       <th className="px-6 py-4 text-center">Conv. Rate</th>
                       <th className="px-6 py-4 text-center">Rev (₹)</th>
                       <th className="px-6 py-4 text-right">Last Seen</th>
                    </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-50">
                    {employeeIntelligence.map((emp) => (
                       <tr key={emp.uid} className="hover:bg-slate-50 transition-colors group">
                          <td className="px-6 py-5">
                             <div className="flex items-center gap-3">
                                <div className="relative">
                                  <div className="w-9 h-9 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black text-xs">
                                     {emp.email.charAt(0).toUpperCase()}
                                  </div>
                                  {emp.isOnline && <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>}
                                </div>
                                <div>
                                   <p className="text-xs font-black text-slate-900 uppercase tracking-tight">{emp.email.split('@')[0]}</p>
                                   <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{emp.role}</p>
                                </div>
                             </div>
                          </td>
                          <td className="px-6 py-5 text-center">
                             <span className="text-xs font-black text-slate-900" title="Total">{emp.stats.total}</span>
                             <span className="text-[10px] font-bold text-green-600" title="Success"> / {emp.stats.approved}</span>
                             <span className="text-[10px] font-bold text-amber-600" title="Negotiations"> / {emp.stats.negotiations}</span>
                          </td>
                        <td className="px-6 py-5">
                           <div className="max-w-[100px] mx-auto space-y-1 text-center">
                              <span className="text-[10px] font-black text-blue-600">{emp.stats.conversion.toFixed(1)}%</span>
                              <div className="w-full h-1 bg-slate-100 rounded-full overflow-hidden">
                                 <div 
                                   className="h-full bg-blue-600 transition-all duration-500" 
                                   style={{ width: `${emp.stats.conversion}%` }}
                                 ></div>
                              </div>
                           </div>
                        </td>
                        <td className="px-6 py-5 text-center font-black text-slate-900 text-sm">₹{Math.round(emp.stats.revenue/1000)}k</td>
                        <td className="px-6 py-5 text-right font-bold text-slate-400 text-[10px] uppercase tracking-tighter shrink-0">
                           {emp.lastSeen ? new Date(emp.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '---'}
                        </td>
                     </tr>
                  ))}
               </tbody>
            </table>
         </div>
      </div>
      )}

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
         <div className="p-6 border-b border-slate-50 flex justify-between items-center">
            <h2 className="text-sm font-black text-slate-900 uppercase tracking-tight">Product Performance Summary</h2>
            <span className="text-[10px] font-black text-slate-400 bg-slate-50 px-2 py-1 rounded">AGGREGATED FOR {selectedMonth}</span>
         </div>
         <div className="overflow-x-auto">
            <table className="w-full text-left">
               <thead>
                  <tr className="bg-slate-50 text-[10px] font-black uppercase tracking-widest text-slate-500">
                     <th className="px-6 py-4">Product Name</th>
                     <th className="px-6 py-4 text-center">Qty Sold</th>
                     <th className="px-6 py-4 text-center">Total Length</th>
                     <th className="px-6 py-4 text-center">Quote Count</th>
                     <th className="px-6 py-4 text-right">Revenue (₹)</th>
                  </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                  {Object.entries(productStats).sort((a,b) => b[1].revenue - a[1].revenue).map(([name, stat]) => (
                     <tr key={name} className="hover:bg-slate-50 transition-colors group">
                        <td className="px-6 py-4 font-black text-slate-900 uppercase text-xs tracking-tight">{name}</td>
                        <td className="px-6 py-4 text-center text-sm font-bold text-slate-600">{stat.qty.toFixed(2)}</td>
                        <td className="px-6 py-4 text-center text-sm font-bold text-slate-600">{stat.length.toFixed(1)} RFT/SQ</td>
                        <td className="px-6 py-4 text-center">
                          <span className="bg-blue-50 text-blue-600 text-[10px] font-black px-2 py-0.5 rounded-full">{stat.count}</span>
                        </td>
                        <td className="px-6 py-4 text-right font-black text-slate-900">₹{stat.revenue.toLocaleString('en-IN')}</td>
                     </tr>
                  ))}
                  {Object.keys(productStats).length === 0 && (
                     <tr>
                        <td colSpan={5} className="p-12 text-center text-[10px] font-black text-slate-300 uppercase tracking-widest italic">
                           No product transactions recorded for this period
                        </td>
                     </tr>
                  )}
               </tbody>
            </table>
         </div>
      </div>
    </div>
  );
};

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(' ');
}
