import React, { useState, useEffect, useRef } from 'react';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, collection, addDoc, serverTimestamp, updateDoc, increment, query, where, getDocs } from 'firebase/firestore';
import { Product, Quotation, Rate, GlobalSettings, DescTemplate } from '../types';
import { Plus, Trash2, Search, Calculator, CheckCircle2, ChevronDown, FileText, Settings, RefreshCcw, TriangleAlert, CircleAlert, Copy, ChevronUp, Layers, Info } from 'lucide-react';
import { cn } from '../lib/utils';
import { PricingUnit, convertRate, convertWidth, calculateItemTotal } from '../lib/unitConverter';
import { InventoryItem } from '../types';

interface QuotationFormProps {
  onGenerated: (quotation: Quotation) => void;
  uid: string;
  initialData?: Partial<Quotation>;
}

interface ValidationErrors {
  custName?: string;
  waNo?: string;
  items?: { [key: number]: { [field: string]: string } };
}

export const QuotationForm: React.FC<QuotationFormProps> = ({ onGenerated, uid, initialData }) => {
  const [custName, setCustName] = useState(initialData?.custName || '');
  const [waNo, setWaNo] = useState(initialData?.waNo || '');
  const [qDate, setQDate] = useState(initialData?.rawDate || new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState(initialData?.notes || '');
  const [items, setItems] = useState<Partial<Product>[]>(initialData?.items || [{}]);
  const [loadV, setLoadV] = useState(initialData?.loadV || 'FREE');
  const [freightV, setFreightV] = useState(initialData?.freightV || 'EXTRA');
  const [loadAmt, setLoadAmt] = useState(0);
  const [freightAmt, setFreightAmt] = useState(0);
  const [settings, setSettings] = useState<GlobalSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [clients, setClients] = useState<{name: string, number: string}[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [showClientSug, setShowClientSug] = useState(false);
  const [showDescSug, setShowDescSug] = useState(false);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [isSuccess, setIsSuccess] = useState(false);

  // Refs for auto-scrolling
  const errorRefs = useRef<{ [key: string]: HTMLElement | null }>({});

  // Load settings, rates, and existing clients for suggestions
  useEffect(() => {
    const fetchSettings = async () => {
      const docRef = doc(db, 'settings', 'global');
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setSettings(docSnap.data() as GlobalSettings);
      }
      
      const clientSnap = await getDocs(collection(db, 'clients'));
      setClients(clientSnap.docs.map(d => d.data() as {name: string, number: string}));

      const invSnap = await getDocs(collection(db, 'inventory'));
      setInventory(invSnap.docs.map(d => ({ ...d.data(), id: d.id } as InventoryItem)));
      
      setLoading(false);
    };
    fetchSettings();
  }, []);

  const addProduct = () => setItems([...items, {}]);
  const removeProduct = (idx: number) => setItems(items.filter((_, i) => i !== idx));

  const duplicateProduct = (idx: number) => {
    const itemToDuplicate = { ...items[idx] };
    // Create a new array with the duplicated item inserted right after the original
    const newItems = [...items];
    newItems.splice(idx + 1, 0, itemToDuplicate);
    setItems(newItems);
  };

  const moveProduct = (idx: number, direction: 'up' | 'down') => {
    if (direction === 'up' && idx === 0) return;
    if (direction === 'down' && idx === items.length - 1) return;
    
    const newItems = [...items];
    const targetIdx = direction === 'up' ? idx - 1 : idx + 1;
    [newItems[idx], newItems[targetIdx]] = [newItems[targetIdx], newItems[idx]];
    setItems(newItems);
  };

  const updateProduct = (idx: number, updates: Partial<Product>) => {
    const newItems = [...items];
    const prevItem = newItems[idx];
    
    // Determine the base and target units
    const baseUnit = (updates.baseUnit || prevItem.baseUnit || 'RFT') as PricingUnit;
    const targetUnit = (updates.unit || prevItem.unit || baseUnit) as PricingUnit;
    
    // Apply updates
    let item = { 
      ...prevItem, 
      ...updates,
      baseUnit,
      unit: targetUnit
    };

    // If unit changed or it's a new item, update rate and width
    if (updates.unit || updates.name) {
      const baseRate = item.rate || 0;
      const standardWidth = item.standardWidth || 3.5;
      
      // Ensure standard width is in feet for cross-type conversion logic
      const standardWidthInFeet = (baseUnit === 'RMT' || baseUnit === 'SQM') 
        ? standardWidth * 3.28084 
        : standardWidth;

      const convertedRate = convertRate(baseRate, baseUnit, targetUnit, standardWidthInFeet);
      item.convertedRate = Number(convertedRate.toFixed(2));
      
      // Update width based on component units
      item.wid = Number(convertWidth(standardWidth, baseUnit, targetUnit).toFixed(2));
    }

    const currentRate = item.convertedRate || item.rate || 0;
    const pcs = item.pcs || 0;
    const len = item.len || 0;
    const wid = item.wid || 0;
    
    const { qty, total } = calculateItemTotal(targetUnit, currentRate, len, wid, pcs);
    
    newItems[idx] = { 
      ...item, 
      qty, 
      total 
    };
    
    setItems(newItems);
  };

  const handleGenerate = async () => {
    const newErrors: ValidationErrors = {};
    const itemErrors: { [key: number]: { [field: string]: string } } = {};

    // 1. Validate Header
    if (!custName.trim()) {
      newErrors.custName = 'Client name is required';
    }
    if (waNo && !/^\d{10}$/.test(waNo)) {
      newErrors.waNo = 'Invalid 10-digit number';
    }

    // 2. Validate Items
    items.forEach((it, idx) => {
      const rowErrs: { [field: string]: string } = {};
      if (!it.name) rowErrs.name = 'Select product';
      if (!it.wid || it.wid <= 0) rowErrs.wid = 'Required';
      if (!it.len || it.len <= 0) rowErrs.len = 'Required';
      if (!it.pcs || it.pcs <= 0) rowErrs.pcs = 'Required';
      if (!it.convertedRate && !it.rate) rowErrs.rate = 'Required';

      if (Object.keys(rowErrs).length > 0) {
        itemErrors[idx] = rowErrs;
      }
    });

    if (Object.keys(itemErrors).length > 0) {
      newErrors.items = itemErrors;
    }

    setErrors(newErrors);

    // 3. Handle Errors (Scroll & Focus)
    if (Object.keys(newErrors).length > 0) {
      // Find first error key
      let firstErrorKey = '';
      if (newErrors.custName) firstErrorKey = 'custName';
      else if (newErrors.waNo) firstErrorKey = 'waNo';
      else if (newErrors.items) {
        const firstIdx = Object.keys(newErrors.items)[0];
        firstErrorKey = `item-${firstIdx}`;
      }

      const errEl = errorRefs.current[firstErrorKey];
      if (errEl) {
        errEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        const input = errEl.querySelector('input, select') as HTMLInputElement | HTMLSelectElement;
        if (input) input.focus();
      }
      return;
    }

    setLoading(true);
    const validItems = items as Product[];
    
    const subTotal = validItems.reduce((s, p) => s + (p.total || 0), 0);
    const lAmt = loadV === 'custom' ? loadAmt : 0;
    const fAmt = freightV === 'custom' ? freightAmt : 0;
    
    const grossTotal = subTotal + lAmt + fAmt; 
    const gst = grossTotal * 0.18;
    const grandTotal = grossTotal + gst;

    // Intelligence: Profit & Hot Deal logic
    let totalProfit = 0;
    validItems.forEach(p => {
      if (p.costPrice && p.costPrice > 0) {
        const profitPerUnit = (p.convertedRate || p.rate || 0) - p.costPrice;
        totalProfit += profitPerUnit * (p.qty || 0);
      }
    });
    const isHotDeal = grandTotal >= 100000;

    const estCounter = settings?.estCounter || 1;
    const estNo = String(estCounter).padStart(4, '0');

    const quotation: Quotation = {
      estNo,
      custName,
      waNo,
      date: new Date(qDate).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      rawDate: qDate,
      notes,
      items: validItems,
      loadV,
      freightV,
      gross: grossTotal.toFixed(2),
      gstAmt: gst.toFixed(2),
      grandTotal: grandTotal.toFixed(2),
      status: 'New',
      createdBy: uid,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      totalProfit,
      isHotDeal
    };

    try {
      // Save to Firestore
      const docRef = await addDoc(collection(db, 'quotations'), quotation);
      
      // Update global counter
      const settingsRef = doc(db, 'settings', 'global');
      await updateDoc(settingsRef, { estCounter: increment(1) });
      
      // Save/Update client
      const q = query(collection(db, 'clients'), where('name', '==', custName));
      const snap = await getDocs(q);
      if (snap.empty) {
        await addDoc(collection(db, 'clients'), {
          name: custName,
          number: waNo,
          lastDate: quotation.date,
          updatedAt: serverTimestamp(),
        });
      } else {
        await updateDoc(doc(db, 'clients', snap.docs[0].id), {
          number: waNo,
          lastDate: quotation.date,
          updatedAt: serverTimestamp(),
        });
      }

      onGenerated({ ...quotation, id: docRef.id });
      setIsSuccess(true);
      setTimeout(() => setIsSuccess(false), 3000);
    } catch (e) {
      console.error(e);
      setErrors({ custName: 'Failed to sync with server. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-slate-50 overflow-hidden">
      {/* 1. STICKY TOP BAR: CUSTOMER CONTEXT */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 px-4 h-12 flex items-center justify-between">
        <div className="flex items-center gap-3 overflow-hidden">
          <div className="flex items-center gap-2.5 border-r border-slate-100 pr-4 mr-1 shrink-0">
            <div className="text-slate-400">
              <FileText size={18} />
            </div>
            <div className="hidden sm:block">
              <p className="text-[9px] font-bold uppercase text-slate-400 leading-none mb-0.5 tracking-tight">Quotation</p>
              <p className="text-xs font-bold text-slate-700 leading-none">#{settings?.estCounter?.toString().padStart(4, '0') || '....'}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <div className="relative group" ref={el => { errorRefs.current['custName'] = el; }}>
              <div className="relative">
                <input 
                  className={cn(
                    "w-48 sm:w-64 bg-slate-50 border h-8 text-xs font-semibold px-3 rounded-md transition-all",
                    errors.custName ? "border-red-300 bg-red-50 focus:border-red-400 focus:ring-red-50" : "border-transparent focus:bg-white focus:border-blue-200"
                  )}
                  placeholder="Client Name *"
                  value={custName}
                  onChange={e => {
                    setCustName(e.target.value);
                    if (errors.custName) setErrors(prev => ({ ...prev, custName: undefined }));
                    setShowClientSug(true);
                  }}
                  onFocus={() => setShowClientSug(true)}
                />
                {errors.custName && (
                  <div className="absolute -bottom-4 left-1 text-[8px] font-bold text-red-500 uppercase tracking-tighter">
                    {errors.custName}
                  </div>
                )}
              </div>
              {showClientSug && custName.length > 1 && (
                <div className="absolute z-[100] left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-lg shadow-xl max-h-64 overflow-y-auto w-[300px]">
                  {clients
                    .filter(c => c.name.toLowerCase().includes(custName.toLowerCase()))
                    .map((c, idx) => (
                      <button
                        key={idx}
                        className="w-full text-left px-4 py-2 hover:bg-slate-50 border-b border-slate-50 last:border-0 transition-colors"
                        onClick={() => {
                          setCustName(c.name);
                          setWaNo(c.number);
                          setShowClientSug(false);
                          setErrors(prev => ({ ...prev, custName: undefined }));
                        }}
                      >
                        <div className="font-bold text-xs text-slate-800">{c.name}</div>
                        <div className="text-[10px] text-slate-400 font-medium">{c.number}</div>
                      </button>
                    ))
                  }
                </div>
              )}
            </div>
            <div className="relative flex flex-col" ref={el => { errorRefs.current['waNo'] = el; }}>
              <input 
                className={cn(
                  "hidden lg:block bg-slate-50 border h-8 text-xs font-medium px-3 rounded-md w-32 transition-all",
                  errors.waNo ? "border-red-300 bg-red-50 focus:border-red-400 focus:ring-red-50" : "border-transparent"
                )}
                placeholder="Mobile No"
                value={waNo}
                onChange={e => {
                  setWaNo(e.target.value.replace(/\D/g, '').slice(0, 10));
                  if (errors.waNo) setErrors(prev => ({ ...prev, waNo: undefined }));
                }}
              />
              {errors.waNo && (
                <div className="absolute -bottom-4 left-1 text-[8px] font-bold text-red-500 uppercase tracking-tighter">
                  {errors.waNo}
                </div>
              )}
            </div>
            <input 
              type="date"
              className="hidden md:block bg-slate-50 border border-transparent h-8 text-[11px] font-medium px-2 rounded-md w-32 text-slate-600"
              value={qDate}
              onChange={e => setQDate(e.target.value)}
            />
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden xl:flex items-center gap-2 mr-4 text-right">
             <div className="flex flex-col items-end">
               <p className="text-[9px] font-bold text-slate-400 uppercase leading-none mb-0.5">Total (Incl GST)</p>
               <p className="text-sm font-bold text-slate-900">₹{Number( (items.reduce((s, p) => s + (p.total || 0), 0) + (loadV === 'custom' ? loadAmt : 0) + (freightV === 'custom' ? freightAmt : 0)) * 1.18 ).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</p>
             </div>
          </div>
          <button 
             onClick={handleGenerate}
             disabled={loading}
             className={cn(
               "h-8 px-4 rounded-md text-xs font-bold transition-all flex items-center gap-2 shadow-sm active:scale-95",
               isSuccess ? "bg-green-600 hover:bg-green-700 text-white" : "bg-blue-600 hover:bg-blue-700 text-white"
             )}
          >
             {isSuccess ? <CheckCircle2 size={14} /> : loading ? <RefreshCcw className="animate-spin" size={14} /> : <CheckCircle2 size={14} />}
             {isSuccess ? "Success!" : loading ? "Syncing..." : "Send & Sync"}
          </button>
        </div>
      </header>

      {/* 2. MAIN OPERATIONAL GRID */}
      <main className="flex-1 flex overflow-hidden">
        {/* Left Column: Items Editor */}
        <section className="flex-1 flex flex-col bg-white overflow-hidden relative border-r border-slate-100">
          <div className="flex items-center justify-between px-6 py-3 border-b border-slate-100 z-10 bg-white">
            <div className="flex items-center gap-3">
              <div className="text-slate-400">
                <Layers size={18} />
              </div>
              <div>
                <h2 className="text-xs font-bold text-slate-800 uppercase tracking-wider">Bill of Materials</h2>
                <p className="text-[10px] text-slate-400 font-medium uppercase">{items.length} active row(s)</p>
              </div>
            </div>
            <button 
              onClick={addProduct}
              className="bg-slate-900 text-white px-3 py-1.5 rounded-md text-[11px] font-bold uppercase tracking-tight hover:bg-black transition-all flex items-center gap-2 active:scale-95 shadow-sm"
            >
              <Plus size={14} /> Add Product
            </button>
          </div>

          {/* Spreadsheet Table Body */}
          <div className="flex-1 overflow-y-auto px-6 py-4 custom-scrollbar bg-white">
            <div className="max-w-5xl mx-auto space-y-3">
              {/* Spreadsheet Headers */}
              <div className="hidden md:grid grid-cols-6 gap-3 px-4 text-[10px] font-bold text-slate-400 tracking-tight mb-[-8px]">
                <div className="col-span-1">Variant Info</div>
                <div>Width (in)</div>
                <div>Length (in)</div>
                <div>Quantity</div>
                <div>Unit</div>
                <div className="text-right">Net Rate</div>
              </div>

              {items.map((item, i) => {
                const isGroupHeader = i === 0 || (items[i-1].name !== item.name || items[i-1].colour !== item.colour || items[i-1].make !== item.make);
                const rowErrors = errors.items?.[i] || {};
                
                return (
                  <div key={i} 
                    ref={el => { errorRefs.current[`item-${i}`] = el; }}
                    className={cn(
                    "p-3 border transition-all duration-200 group relative",
                    isGroupHeader ? "border-slate-200 rounded-t-lg mt-3 bg-slate-50/30" : "border-slate-100 border-t-0 rounded-none bg-white",
                    i === items.length - 1 ? "rounded-b-lg mb-8" : "",
                    !isGroupHeader && "pt-1 pb-2",
                    Object.keys(rowErrors).length > 0 && "border-red-200 bg-red-50/20 ring-1 ring-red-100"
                  )}>
                    {/* Action Bar (Pinned to top right) */}
                    <div className="absolute top-1.5 right-3 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-all bg-white border border-slate-100 shadow-sm p-1 rounded-md z-10">
                      <button onClick={() => moveProduct(i, 'up')} title="Move Up" className={cn("p-1 rounded hover:bg-slate-50 transition-colors", i === 0 ? "text-slate-200 cursor-not-allowed" : "text-slate-400 hover:text-blue-600")}><ChevronUp size={14} /></button>
                      <button onClick={() => moveProduct(i, 'down')} title="Move Down" className={cn("p-1 rounded hover:bg-slate-50 transition-colors", i === items.length - 1 ? "text-slate-200 cursor-not-allowed" : "text-slate-400 hover:text-blue-600")}><ChevronDown size={14} /></button>
                      <button onClick={() => duplicateProduct(i)} title="Duplicate Row" className="p-1 rounded hover:bg-amber-50 text-slate-400 hover:text-amber-600 transition-colors"><Copy size={13} /></button>
                      {items.length > 1 && (
                        <button onClick={() => removeProduct(i)} title="Remove Row" className="p-1 rounded hover:bg-red-50 text-slate-400 hover:text-red-500 transition-colors">
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>

                    <div className="grid gap-3">
                      {isGroupHeader ? (
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          <div className="col-span-1">
                            <label className="text-[9px] font-bold text-slate-500 uppercase mb-1 block">Product Group *</label>
                            <select 
                              className={cn(
                                "w-full text-xs font-bold uppercase h-8 border rounded-md transition-all",
                                rowErrors.name ? "border-red-300 bg-red-50 text-red-600" : "border-slate-200 bg-white"
                              )}
                              value={settings?.rates.findIndex(r => r.name === item.name) ?? -1}
                              onChange={(e) => {
                                const val = parseInt(e.target.value);
                                if (val >= 0) {
                                  const r = settings!.rates[val];
                                  updateProduct(i, { 
                                    name: r.name, 
                                    rate: r.rate, 
                                    rUnit: r.unit, 
                                    baseUnit: (r.baseUnit || 'RFT') as PricingUnit,
                                    unit: (r.baseUnit || 'RFT') as PricingUnit,
                                    wid: r.width, 
                                    standardWidth: r.width,
                                    hsn: r.hsn 
                                  });

                                  if (r.description) {
                                    setNotes(prev => {
                                      if (prev.includes(r.description!)) return prev;
                                      return prev ? `${prev}\n\n${r.description}` : r.description!;
                                    });
                                  }
                                  if (errors.items?.[i]?.name) {
                                    const nextItems = { ...errors.items };
                                    delete nextItems[i].name;
                                    setErrors({ ...errors, items: nextItems });
                                  }
                                }
                              }}
                            >
                              <option value="-1">Select Material...</option>
                              {settings?.rates.map((r, idx) => (
                                <option key={idx} value={idx}>{r.name}</option>
                              ))}
                            </select>
                          </div>

                          <div>
                            <label className="text-[9px] font-bold text-slate-500 uppercase mb-1 block">Make</label>
                            <select 
                              className="w-full text-xs font-medium h-8 border-slate-200 bg-white rounded-md"
                              value={item.make || ''} 
                              onChange={e => {
                                updateProduct(i, { make: e.target.value, colour: '', thickness: '', gsm: '' });
                              }}
                            >
                               <option value="">Brand...</option>
                               {Array.from(new Set(inventory.map(it => it.make))).map(m => (
                                  <option key={m} value={m}>{m}</option>
                               ))}
                            </select>
                          </div>
                          <div>
                            <label className="text-[9px] font-bold text-slate-500 uppercase mb-1 block">Variant</label>
                            <select 
                              className="w-full text-xs font-medium h-8 border-slate-200 bg-white rounded-md"
                              value={item.colour || ''} 
                              onChange={e => {
                                const colour = e.target.value;
                                const match = inventory.find(it => it.make === item.make && it.colour === colour);
                                if (match) {
                                   updateProduct(i, { 
                                     colour, 
                                     thickness: match.thickness, 
                                     gsm: match.gsm,
                                     category: match.category
                                   });
                                } else {
                                   updateProduct(i, { colour });
                                }
                              }}
                              disabled={!item.make}
                            >
                               <option value="">Color / Finish...</option>
                               {inventory.filter(it => it.make === item.make).map((it) => (
                                  <option key={it.id} value={it.colour}>{it.colour}</option>
                               ))}
                            </select>
                          </div>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 mb-[-6px]">
                          <div className="w-0.5 h-3 bg-slate-300 rounded-full ml-1"></div>
                          <span className="text-[9px] font-medium text-slate-400 italic">Variant of above product</span>
                        </div>
                      )}

                      {/* Spreadsheet Row */}
                      <div className="grid grid-cols-4 md:grid-cols-6 gap-2 bg-white/50 p-1 rounded-md border border-slate-100 shadow-inner">
                        <div className="col-span-1">
                          <input 
                            value={item.thickness || '—'}
                            readOnly
                            className="w-full h-8 px-2 text-xs font-medium bg-slate-50/50 border-none rounded text-slate-400 text-center"
                          />
                        </div>
                        <div>
                          <input 
                            type="number" 
                            step="0.001"
                            className={cn(
                              "w-full h-8 px-2 text-xs font-semibold border-none focus:ring-1 rounded text-center transition-all",
                              rowErrors.wid ? "bg-red-50 ring-1 ring-red-200 placeholder:text-red-300" : "focus:ring-blue-100"
                            )}
                            placeholder="W"
                            value={item.wid || ''}
                            onChange={e => {
                              updateProduct(i, { wid: parseFloat(e.target.value) });
                              if (rowErrors.wid) {
                                const nextItems = { ...errors.items };
                                delete nextItems[i].wid;
                                setErrors({ ...errors, items: nextItems });
                              }
                            }}
                          />
                        </div>
                        <div>
                          <input 
                            type="number" 
                            step="0.001"
                            className={cn(
                              "w-full h-8 px-2 text-xs font-semibold border-none focus:ring-1 rounded text-center transition-all",
                              rowErrors.len ? "bg-red-50 ring-1 ring-red-200 placeholder:text-red-300" : "focus:ring-blue-100"
                            )}
                            placeholder="L"
                            value={item.len || ''}
                            onChange={e => {
                              updateProduct(i, { len: parseFloat(e.target.value) });
                              if (rowErrors.len) {
                                const nextItems = { ...errors.items };
                                delete nextItems[i].len;
                                setErrors({ ...errors, items: nextItems });
                              }
                            }}
                          />
                        </div>
                        <div>
                          <input 
                            type="number" 
                            className={cn(
                              "w-full h-8 px-2 text-xs font-semibold border-none focus:ring-1 rounded text-center transition-all font-mono",
                              rowErrors.pcs ? "bg-red-50 ring-1 ring-red-200 placeholder:text-red-300" : "focus:ring-blue-100"
                            )}
                            placeholder="Pcs"
                            value={item.pcs || ''}
                            onChange={e => {
                              updateProduct(i, { pcs: parseFloat(e.target.value) });
                              if (rowErrors.pcs) {
                                const nextItems = { ...errors.items };
                                delete nextItems[i].pcs;
                                setErrors({ ...errors, items: nextItems });
                              }
                            }}
                          />
                        </div>
                        <div className="hidden md:block">
                          <select 
                            className="w-full h-8 px-1 text-[11px] font-bold uppercase bg-transparent border-none focus:ring-0 text-center text-slate-500"
                            value={item.unit || 'RFT'}
                            onChange={e => updateProduct(i, { unit: e.target.value as PricingUnit })}
                          >
                            {['RFT', 'RMT', 'SQFT', 'SQM'].map(u => (
                              <option key={u} value={u}>{u}</option>
                            ))}
                          </select>
                        </div>
                        <div className="hidden md:block text-right">
                          <div className={cn(
                            "flex items-center justify-end h-8 pr-2 rounded transition-all",
                            rowErrors.rate ? "bg-red-50 ring-1 ring-red-100" : ""
                          )}>
                             <span className={cn("text-[10px] mr-1", rowErrors.rate ? "text-red-400" : "text-slate-300")}>₹</span>
                             <input 
                                type="number" 
                                step="0.01"
                                className={cn(
                                  "w-16 h-8 p-0 text-right text-xs font-bold bg-transparent border-none focus:ring-0",
                                  rowErrors.rate ? "text-red-600 placeholder:text-red-300" : ""
                                )}
                                placeholder="Rate"
                                value={item.convertedRate || item.rate || ''}
                                onChange={e => {
                                  updateProduct(i, { convertedRate: parseFloat(e.target.value) });
                                  if (rowErrors.rate) {
                                    const nextItems = { ...errors.items };
                                    delete nextItems[i].rate;
                                    setErrors({ ...errors, items: nextItems });
                                  }
                                }}
                             />
                          </div>
                        </div>
                      </div>

                      {/* Row Total & Summary */}
                      <div className="flex justify-between items-center px-1">
                        <div className="flex items-center gap-4">
                           {item.qty && (
                              <div className="flex items-center gap-1.5 text-[10px]">
                                 <span className="font-medium text-slate-400 uppercase tracking-wider">Total Quantity:</span>
                                 <span className="font-bold text-slate-700">{item.qty} {item.unit}</span>
                              </div>
                           )}
                        </div>
                        {item.total && (
                          <div className="text-right">
                            <span className="text-xs font-bold text-slate-800">₹ {item.total.toLocaleString('en-IN')}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Right Column: Sticky Summary & Sidebar */}
        <aside className="w-80 bg-slate-50 border-l border-slate-200 flex flex-col z-30">
          <div className="p-5 overflow-y-auto flex-1 custom-scrollbar space-y-6">
            
            {/* 3. QUOTATION SUMMARY BOX */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 px-1">
                <Calculator size={16} className="text-slate-400" />
                <h2 className="text-xs font-bold text-slate-700 uppercase tracking-wider">Summary</h2>
              </div>

              <div className="bg-white rounded-xl p-4 space-y-3.5 border border-slate-200 shadow-sm">
                <div className="flex justify-between items-center text-[11px] font-medium text-slate-500">
                  <span>Subtotal</span>
                  <span className="text-slate-700 font-bold">₹{items.reduce((s, p) => s + (p.total || 0), 0).toLocaleString('en-IN')}</span>
                </div>

                <div className="space-y-2.5 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-medium text-slate-500 uppercase">Loading</label>
                    <div className="flex items-center gap-1.5">
                      <select className="h-6 text-[10px] font-bold bg-slate-50 border-slate-200 rounded" value={loadV} onChange={e => setLoadV(e.target.value)}>
                        <option value="FREE">FREE</option>
                        <option value="EXTRA">EXTRA</option>
                        <option value="custom">AMT</option>
                      </select>
                      {loadV === 'custom' && (
                        <input type="number" className="h-6 w-14 text-[10px] font-bold border-slate-200 rounded" value={loadAmt || ''} onChange={e => setLoadAmt(parseFloat(e.target.value) || 0)} />
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-medium text-slate-500 uppercase">Freight</label>
                    <div className="flex items-center gap-1.5">
                      <select className="h-6 text-[10px] font-bold bg-slate-50 border-slate-200 rounded" value={freightV} onChange={e => setFreightV(e.target.value)}>
                        <option value="EXTRA">EXTRA</option>
                        <option value="FREE">FREE</option>
                        <option value="custom">AMT</option>
                      </select>
                      {freightV === 'custom' && (
                        <input type="number" className="h-6 w-14 text-[10px] font-bold border-slate-200 rounded" value={freightAmt || ''} onChange={e => setFreightAmt(parseFloat(e.target.value) || 0)} />
                      )}
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-200">
                  <div className="flex justify-between items-center text-[10px] font-medium text-slate-400 mb-1">
                    <span>Tax (GST 18%)</span>
                    <span>₹{( (items.reduce((s, p) => s + (p.total || 0), 0) + (loadV === 'custom' ? loadAmt : 0) + (freightV === 'custom' ? freightAmt : 0)) * 0.18 ).toLocaleString('en-IN', { maximumFractionDigits: 2 })}</span>
                  </div>
                  
                  <div className="flex justify-between items-end pt-1">
                    <div>
                      <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider leading-none mb-1">Grand Total</p>
                      <p className="text-lg font-bold text-slate-900 leading-none">₹ {Number( (items.reduce((s, p) => s + (p.total || 0), 0) + (loadV === 'custom' ? loadAmt : 0) + (freightV === 'custom' ? freightAmt : 0)) * 1.18 ).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</p>
                    </div>
                    <div className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded">
                      Commercial
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 4. DESCRIPTION & NOTES STYLED AS FIELD DATA */}
            <div className="space-y-3">
              <div className="flex items-center justify-between px-1">
                <label className="text-[10px] font-bold uppercase text-slate-500">Notes & Specs</label>
                <div className="flex gap-1.5">
                  {settings?.descTmpls?.slice(0, 2).map((t, idx) => (
                    <button 
                      key={idx}
                      onClick={() => setNotes(prev => prev ? `${prev}\n${t.text}` : t.text)}
                      className="text-[9px] font-bold text-blue-600 hover:underline"
                    >
                      {t.title}
                    </button>
                  ))}
                </div>
              </div>
              <textarea 
                className="w-full min-h-[120px] text-xs font-medium leading-relaxed text-slate-600 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-100 p-3 transition-all"
                placeholder="Technical notes, address etc..."
                value={notes}
                onChange={e => setNotes(e.target.value)}
              />
            </div>

            {/* Additional Actions */}
            <div className="flex gap-2 pt-2">
              <button className="flex-1 flex items-center justify-center gap-2 h-9 bg-white border border-slate-200 rounded-lg text-[10px] font-bold uppercase text-slate-600 hover:bg-slate-50">
                <Settings size={12} /> Config
              </button>
              <button 
                onClick={() => setItems([{}])}
                className="flex-1 flex items-center justify-center gap-2 h-9 bg-white border border-slate-200 rounded-lg text-[10px] font-bold uppercase text-slate-600 hover:bg-slate-50"
              >
                Reset
              </button>
            </div>
          </div>

          <div className="p-4 border-t border-slate-200 bg-white">
             <button 
               onClick={handleGenerate}
               className="w-full bg-blue-600 text-white h-11 rounded-lg font-bold text-sm hover:bg-blue-700 active:scale-95 transition-all flex items-center justify-center gap-2"
             >
               Preview Quote <Search size={16} />
             </button>
          </div>
        </aside>
      </main>
    </div>
  );
};
