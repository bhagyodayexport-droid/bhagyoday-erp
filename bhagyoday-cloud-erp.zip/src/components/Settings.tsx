import React, { useState, useEffect } from 'react';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { GlobalSettings, Rate, DescTemplate } from '../types';
import { Save, Plus, Trash2, Building, FileText, Briefcase, Link as LinkIcon, Database, ShieldCheck } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuth } from '../context/AuthContext';

export const SettingsLayout: React.FC = () => {
  const [settings, setSettings] = useState<GlobalSettings | null>(null);
  const [activeSec, setActiveSec] = useState('company');
  const [loading, setLoading] = useState(true);
  const { profile } = useAuth();

  useEffect(() => {
    const fetch = async () => {
      const snap = await getDoc(doc(db, 'settings', 'global'));
      if (snap.exists()) setSettings(snap.data() as GlobalSettings);
      setLoading(false);
    };
    fetch();
  }, []);

  const saveSettings = async (updates: Partial<GlobalSettings>) => {
    if (!settings) return;
    const newSettings = { ...settings, ...updates };
    setSettings(newSettings);
    await setDoc(doc(db, 'settings', 'global'), newSettings);
    alert('Settings Saved Successfully');
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, field: 'logo' | 'qrCode') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSettings({
          ...settings!,
          company: {
            ...settings!.company,
            [field]: reader.result as string
          }
        });
      };
      reader.readAsDataURL(file);
    }
  };

  if (loading || !settings) return <div className="p-12 text-center text-[10px] font-black uppercase tracking-widest text-slate-400">Loading Configuration...</div>;

  const sections = [
    { id: 'company', label: 'Company Info', icon: Building },
    { id: 'pdf', label: 'PDF & Footer Control', icon: FileText },
    { id: 'rates', label: 'Standard Rates', icon: Briefcase },
    { id: 'general', label: 'Integrations', icon: LinkIcon },
    { id: 'staff', label: 'Staff Access', icon: ShieldCheck, adminOnly: true },
  ].filter(s => !s.adminOnly || profile?.role === 'admin');

  return (
    <div className="max-w-6xl mx-auto p-6 flex flex-col md:flex-row gap-6">
      <aside className="md:w-64 space-y-1">
        {sections.map(s => (
          <button
            key={s.id}
            onClick={() => setActiveSec(s.id)}
            className={cn(
              "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-all",
              activeSec === s.id 
                ? "bg-slate-900 text-white shadow-lg shadow-slate-200" 
                : "text-slate-500 hover:bg-slate-100"
            )}
          >
            <s.icon size={18} />
            {s.label}
          </button>
        ))}
      </aside>

      <main className="flex-1 bg-white rounded-2xl border border-slate-200 p-8 shadow-sm">
        {activeSec === 'company' && (
          <div className="space-y-6">
             <h2 className="text-xl font-black text-slate-900 border-b border-slate-100 pb-4">Business Profile</h2>
             <div className="grid md:grid-cols-2 gap-8 mb-4">
                <div className="space-y-2">
                   <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Company Logo</label>
                   <div className="flex items-center gap-4">
                      <div className="w-20 h-20 bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden">
                        {settings.company.logo ? (
                          <img src={settings.company.logo} alt="Logo" className="w-full h-full object-contain" />
                        ) : (
                          <Building className="text-slate-300" size={32} />
                        )}
                      </div>
                      <input 
                        type="file" 
                        accept="image/*"
                        onChange={e => handleFileUpload(e, 'logo')}
                        className="text-[10px] file:bg-slate-900 file:text-white file:border-0 file:px-3 file:py-1 file:rounded file:font-black file:uppercase file:mr-4 cursor-pointer"
                      />
                   </div>
                </div>

                <div className="space-y-2">
                   <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Contact QR Code</label>
                   <div className="flex items-center gap-4">
                      <div className="w-20 h-20 bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 flex items-center justify-center overflow-hidden">
                        {settings.company.qrCode ? (
                          <img src={settings.company.qrCode} alt="QR" className="w-full h-full object-contain" />
                        ) : (
                          <Database className="text-slate-300" size={32} />
                        )}
                      </div>
                      <input 
                        type="file" 
                        accept="image/*"
                        onChange={e => handleFileUpload(e, 'qrCode')}
                        className="text-[10px] file:bg-slate-900 file:text-white file:border-0 file:px-3 file:py-1 file:rounded file:font-black file:uppercase file:mr-4 cursor-pointer"
                      />
                   </div>
                </div>
             </div>
             
             <div className="grid md:grid-cols-2 gap-4">
                <div>
                   <label>Company Name</label>
                   <input className="w-full" value={settings.company.name} onChange={e => setSettings({...settings, company: {...settings.company, name: e.target.value}})} />
                </div>
                <div>
                   <label>Social Media / Website URL</label>
                   <input 
                     className="w-full" 
                     placeholder="bhagyodayroof.com / @bhagyoday"
                     value={settings.company.social || ''} 
                     onChange={e => setSettings({...settings, company: {...settings.company, social: e.target.value}})} 
                   />
                </div>
                <div className="md:col-span-2">
                   <label>Address Line 1</label>
                   <input className="w-full" value={settings.company.addr1} onChange={e => setSettings({...settings, company: {...settings.company, addr1: e.target.value}})} />
                </div>
                <div>
                   <label>GST Number</label>
                   <input className="w-full" value={settings.company.gst} onChange={e => setSettings({...settings, company: {...settings.company, gst: e.target.value}})} />
                </div>
                <div>
                   <label>Phone Number</label>
                   <input className="w-full" value={settings.company.phone} onChange={e => setSettings({...settings, company: {...settings.company, phone: e.target.value}})} />
                </div>
             </div>
             <button onClick={() => saveSettings(settings)} className="bg-slate-900 text-white px-6 py-2 rounded font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
               <Save size={14} /> Update Profile
             </button>
          </div>
        )}


         {activeSec === 'pdf' && (
          <div className="space-y-6">
             <div className="flex justify-between items-center border-b border-slate-100 pb-4">
                <h2 className="text-xl font-black text-slate-900">Document Control</h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Full control over PDF footer and labels</p>
             </div>
             
             <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 italic space-y-4">
                <div>
                   <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-1.5 flex justify-between">
                     <span>Custom Footer Greeting (Signature)</span>
                     <span className="text-blue-500 font-bold tracking-normal not-italic text-[9px]">e.g. WITH BEST REGARD PARTH PATEL</span>
                   </label>
                   <input 
                     className="w-full bg-white font-black uppercase" 
                     placeholder="WITH BEST REGARD PARTH PATEL"
                     value={settings.pdfCfg.footerRegards || ''} 
                     onChange={e => setSettings({...settings, pdfCfg: {...settings.pdfCfg, footerRegards: e.target.value}})} 
                   />
                </div>
             </div>

             <div>
                <label>Terms & Conditions (One per line)</label>
                <textarea 
                  className="w-full h-40" 
                  value={settings.pdfCfg.terms} 
                  onChange={e => setSettings({...settings, pdfCfg: {...settings.pdfCfg, terms: e.target.value}})} 
                />
             </div>
             <div>
                <label>Bank Details Displayed on PDF</label>
                <textarea 
                  className="w-full h-24" 
                  value={settings.pdfCfg.bank} 
                  onChange={e => setSettings({...settings, pdfCfg: {...settings.pdfCfg, bank: e.target.value}})} 
                />
             </div>
             <div>
                <label>Default PDF Footer (Small Text)</label>
                <input 
                  className="w-full" 
                  value={settings.pdfCfg.footer} 
                  onChange={e => setSettings({...settings, pdfCfg: {...settings.pdfCfg, footer: e.target.value}})} 
                />
             </div>
             <button onClick={() => saveSettings(settings)} className="bg-slate-900 text-white px-6 py-2 rounded font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
               <Save size={14} /> Update Document Settings
             </button>
          </div>
        )}

         {activeSec === 'rates' && (
            <div className="space-y-8">
               <div className="flex justify-between items-center border-b-2 border-slate-900 pb-4">
                  <div className="pl-4 border-l-4 border-blue-600">
                    <h2 className="text-xl font-black text-slate-900 uppercase tracking-tight">Standard Rates</h2>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Configure your product master and price list</p>
                  </div>
                  <button 
                    onClick={() => setSettings({...settings, rates: [...settings.rates, {name: '', rate: 0, unit: 'RFT', baseUnit: 'RFT', width: 3.5, standardWidth: 3.5, hsn: '7210', description: ''}]})}
                    className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
                  >
                    <Plus size={14} /> Add New Entry
                  </button>
              </div>
              <div className="space-y-6">
                 {settings.rates.map((r, i) => (
                    <div key={i} className="relative group">
                       <div className="absolute -left-3 top-0 bottom-0 w-1 bg-slate-100 group-hover:bg-blue-200 transition-colors rounded-full" />
                       <div className="p-6 bg-white border border-slate-100 rounded-2xl shadow-sm hover:shadow-md transition-all space-y-5">
                          <div className="flex flex-col md:flex-row gap-6">
                             <div className="flex-1 space-y-1.5">
                                <label className="text-[9px] font-black uppercase text-slate-400 tracking-[0.15em]">Item / Product Name</label>
                                <input 
                                  className="w-full text-sm font-black uppercase tracking-tight text-slate-800 bg-slate-50/50" 
                                  value={r.name} 
                                  onChange={e => {
                                    const newRates = [...settings.rates];
                                    newRates[i].name = e.target.value;
                                    setSettings({...settings, rates: newRates});
                                  }} 
                                />
                             </div>
                             <div className="flex gap-4">
                                <div className="w-28 space-y-1.5">
                                   <label className="text-[9px] font-black uppercase text-slate-400 tracking-[0.15em]">Rate (₹)</label>
                                   <input 
                                     type="number" 
                                     className="w-full font-black text-blue-600 bg-slate-50/50" 
                                     value={r.rate} 
                                     onChange={e => {
                                       const newRates = [...settings.rates];
                                       newRates[i].rate = parseFloat(e.target.value) || 0;
                                       setSettings({...settings, rates: newRates});
                                     }} 
                                   />
                                </div>
                                <div className="w-24 space-y-1.5">
                                   <label className="text-[9px] font-black uppercase text-slate-400 tracking-[0.15em]">Unit</label>
                                   <select 
                                     className="w-full font-black text-slate-600 bg-slate-50/50 border-none px-3" 
                                     value={r.baseUnit || r.unit} 
                                     onChange={e => {
                                       const newRates = [...settings.rates];
                                       const unit = e.target.value as any;
                                       newRates[i].baseUnit = unit;
                                       newRates[i].unit = unit;
                                       setSettings({...settings, rates: newRates});
                                     }}
                                   >
                                      {['RFT', 'RMT', 'SQFT', 'SQM'].map(u => <option key={u} value={u}>{u}</option>)}
                                   </select>
                                </div>
                             </div>
                          </div>
                          
                          <div className="grid md:grid-cols-3 gap-6 pt-2">
                             <div className="space-y-1.5">
                                <label className="text-[9px] font-black uppercase text-slate-400 tracking-[0.15em] flex justify-between">
                                   <span>Width</span>
                                   <span>{r.baseUnit === 'RMT' || r.baseUnit === 'SQM' ? 'METERS' : 'FEET'}</span>
                                </label>
                                <input 
                                  type="number" 
                                  step="0.001"
                                  className="w-full text-xs font-bold" 
                                  value={r.standardWidth || r.width} 
                                  onChange={e => {
                                    const newRates = [...settings.rates];
                                    const val = parseFloat(e.target.value) || 0;
                                    newRates[i].standardWidth = val;
                                    newRates[i].width = val;
                                    setSettings({...settings, rates: newRates});
                                  }} 
                                />
                             </div>
                             <div className="space-y-1.5">
                                <label className="text-[9px] font-black uppercase text-slate-400 tracking-[0.15em]">HSN / SAC</label>
                                <input 
                                  className="w-full text-xs font-bold" 
                                  value={r.hsn || ''} 
                                  onChange={e => {
                                    const newRates = [...settings.rates];
                                    newRates[i].hsn = e.target.value;
                                    setSettings({...settings, rates: newRates});
                                  }} 
                                />
                             </div>
                             <div className="flex items-end pb-1.5">
                                <button 
                                  onClick={() => {
                                     if (confirm('Remove this product?')) {
                                       const newRates = settings.rates.filter((_, idx) => idx !== i);
                                       setSettings({...settings, rates: newRates});
                                     }
                                  }}
                                  className="flex items-center gap-2 text-red-400 hover:text-red-600 transition-colors text-[10px] font-black uppercase tracking-widest pl-2"
                                >
                                  <Trash2 size={14} /> Remove Product
                                </button>
                             </div>
                          </div>

                          <div className="pt-2">
                             <label className="text-[9px] font-black uppercase text-slate-400 tracking-[0.15em] mb-2 block">Specifications (Auto-Fill Description)</label>
                             <textarea 
                               className="w-full h-20 text-xs font-bold text-slate-600 bg-slate-50/30 p-4 border-slate-100 italic" 
                               placeholder="e.g. 0.50MM TCT | IS CODE 14246 | AZ-150 GSM..."
                               value={r.description || ''} 
                               onChange={e => {
                                 const newRates = [...settings.rates];
                                 newRates[i].description = e.target.value;
                                 setSettings({...settings, rates: newRates});
                               }} 
                             />
                          </div>
                       </div>
                    </div>
                 ))}
              </div>
              <div className="pt-6 border-t border-slate-100 flex justify-end">
                 <button onClick={() => saveSettings(settings)} className="bg-slate-900 text-white px-10 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest flex items-center gap-3 shadow-xl shadow-slate-200 active:scale-95 transition-all">
                    <Save size={18} /> Save Price List Configuration
                 </button>
              </div>
           </div>
        )}

        {activeSec === 'general' && (
           <div className="space-y-6">
              <h2 className="text-xl font-black text-slate-900 border-b border-slate-100 pb-4">External Sync</h2>
              <div className="p-5 bg-blue-50 border border-blue-100 rounded-xl">
                 <div className="flex gap-4">
                    <div className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center text-white shadow-lg">
                      <Database size={20} />
                    </div>
                    <div>
                       <h3 className="font-bold text-blue-900">Google Sheets Integration</h3>
                       <p className="text-xs text-blue-700 mt-1">Automatically log every quotation to a central spreadsheet for master auditing.</p>
                       <input 
                         className="w-full mt-4 bg-white border-blue-200" 
                         placeholder="Deployment Script URL..."
                         value={settings.scriptUrl}
                         onChange={e => setSettings({...settings, scriptUrl: e.target.value})}
                       />
                    </div>
                 </div>
              </div>
              <button onClick={() => saveSettings(settings)} className="bg-slate-900 text-white px-6 py-2 rounded font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
               <Save size={14} /> Update Integraion
             </button>
           </div>
        )}

        {activeSec === 'staff' && (
           <div className="space-y-6">
              <h2 className="text-xl font-black text-slate-900 border-b border-slate-100 pb-4">Employee Tab Permissions</h2>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-tight mb-6">Control which features are visible to secondary users</p>
              
              <div className="grid gap-3">
                 {[
                   { id: 'canAccessHistory', label: '📋 View History List', desc: 'Allows employees to see previous quotations' },
                   { id: 'canAccessClients', label: '👥 View Client Database', desc: 'Allows employees to see saved customer information' },
                   { id: 'canAccessSales', label: '📊 View Sales Analytics', desc: 'Allows employees to see monthly performance reports' },
                   { id: 'canAccessSettings', label: '⚙️ Access Settings', desc: 'Allows employees to modify business config' },
                 ].map(p => (
                   <div key={p.id} className="flex items-center justify-between p-4 bg-slate-50 border border-slate-100 rounded-xl group hover:border-blue-200 transition-colors">
                      <div>
                         <p className="text-xs font-black text-slate-900 uppercase tracking-widest">{p.label}</p>
                         <p className="text-[10px] text-slate-400 font-bold">{p.desc}</p>
                      </div>
                      <button 
                        onClick={() => {
                          const currentPerms = settings.empPermissions || { canAccessHistory: true, canAccessClients: true, canAccessSales: false, canAccessSettings: false, canAccessInventory: true };
                          setSettings({
                            ...settings,
                            empPermissions: {
                              ...currentPerms,
                              [p.id]: !((currentPerms as any)[p.id])
                            }
                          });
                        }}
                        className={cn(
                          "w-12 h-6 rounded-full relative transition-all duration-300",
                          (settings.empPermissions?.[p.id as keyof typeof settings.empPermissions]) ? "bg-blue-600" : "bg-slate-300"
                        )}
                      >
                        <div className={cn(
                          "absolute top-1 w-4 h-4 bg-white rounded-full transition-all duration-300 shadow-sm",
                          (settings.empPermissions?.[p.id as keyof typeof settings.empPermissions]) ? "left-7" : "left-1"
                        )} />
                      </button>
                   </div>
                 ))}
              </div>

              <div className="p-4 bg-amber-50 border border-amber-100 rounded-xl flex gap-3 mt-8">
                 <ShieldCheck className="text-amber-600 shrink-0" size={18} />
                 <p className="text-[10px] text-amber-900 font-bold leading-relaxed uppercase">
                   Changes here affect all employees instantly. Admins always have full access regardless of these settings.
                 </p>
              </div>

              <button onClick={() => saveSettings(settings)} className="bg-slate-900 text-white px-6 py-2 rounded font-black text-[10px] uppercase tracking-widest flex items-center gap-2">
               <Save size={14} /> Update Access Rules
             </button>
           </div>
        )}
      </main>
    </div>
  );
};
