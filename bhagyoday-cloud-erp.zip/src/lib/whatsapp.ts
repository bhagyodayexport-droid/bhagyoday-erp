import { Quotation } from '../types';

export const sendWhatsAppPdf = async (quotation: Quotation) => {
  try {
    const response = await fetch('/api/whatsapp/send-quotation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        quotationData: {
          ...quotation,
          date: quotation.date,
          custName: quotation.custName,
          custPhone: quotation.waNo,
          estNo: quotation.estNo,
          items: quotation.items,
          grandTotal: quotation.grandTotal
        },
        phoneNumber: quotation.waNo
      })
    });

    const result = await response.json();
    return result;
  } catch (error: any) {
    console.error('WhatsApp Service Error:', error);
    throw error;
  }
};
