export type PricingUnit = 'RFT' | 'RMT' | 'SQFT' | 'SQM';

export const CONVERSION_FACTORS = {
  M_TO_FT: 3.28084,
  FT_TO_M: 1 / 3.28084,
  SQM_TO_SQFT: 10.7639,
  SQFT_TO_SQM: 1 / 10.7639,
};

export const convertRate = (rate: number, from: PricingUnit, to: PricingUnit, widthInFeet?: number): number => {
  if (from === to) return rate;

  // Standardization: First convert to base feet-based units
  let rateInBase = rate;
  if (from === 'RMT') rateInBase = rate / CONVERSION_FACTORS.M_TO_FT;
  if (from === 'SQM') rateInBase = rate / CONVERSION_FACTORS.SQM_TO_SQFT;

  // Intermediate unit is now RFT or SQFT
  const fromIsLinear = from === 'RFT' || from === 'RMT';
  const toIsLinear = to === 'RFT' || to === 'RMT';

  if (fromIsLinear && !toIsLinear && widthInFeet) {
    // RFT -> SQFT: rate is per foot, need per sqft. 
    // If 1ft costs R, and it covers W sqft, then 1sqft costs R/W
    rateInBase = rateInBase / widthInFeet;
  } else if (!fromIsLinear && toIsLinear && widthInFeet) {
    // SQFT -> RFT: rate is per sqft, need per foot.
    // If 1sqft costs R, and 1ft covers W sqft, then 1ft costs R*W
    rateInBase = rateInBase * widthInFeet;
  }

  // Final conversion to target unit
  if (to === 'RMT') return rateInBase * CONVERSION_FACTORS.M_TO_FT;
  if (to === 'SQM') return rateInBase * CONVERSION_FACTORS.SQM_TO_SQFT;
  
  return rateInBase;
};

export const convertWidth = (width: number, from: PricingUnit, to: PricingUnit): number => {
  if (from === to) return width;
  
  const fromIsMetric = from === 'RMT' || from === 'SQM';
  const toIsMetric = to === 'RMT' || to === 'SQM';

  if (!fromIsMetric && toIsMetric) return width * CONVERSION_FACTORS.FT_TO_M;
  if (fromIsMetric && !toIsMetric) return width * CONVERSION_FACTORS.M_TO_FT;

  return width;
};

export const calculateItemTotal = (
  unit: PricingUnit,
  rate: number,
  len: number,
  wid: number,
  pcs: number
): { qty: number; total: number } => {
  let qty = 0;
  
  if (unit === 'RFT' || unit === 'RMT') {
    qty = len * pcs;
  } else if (unit === 'SQFT' || unit === 'SQM') {
    qty = len * wid * pcs;
  }

  return {
    qty: Number(qty.toFixed(2)),
    total: Number((qty * rate).toFixed(2))
  };
};
