import { collection, doc, getDocs, setDoc, writeBatch, query, where, addDoc, getDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth } from './firebase';
import { InventoryItem, Product, DispatchLog, Quotation } from '../types';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  const serialized = JSON.stringify(errInfo);
  console.error('Firestore Error Detailed: ', serialized);
  throw new Error(serialized);
}

export const getMaterialKey = (make: string = '', colour: string = '', thickness: string = '', gsm: string = '', category: string = 'GENERAL', productName: string = '') => {
  const sanitize = (s: string) => String(s || '').trim().toUpperCase().replace(/[\/\\]/g, '-');
  // If we have a productName, that's our unique identifier within category
  if (productName) {
    return `${sanitize(category)}_${sanitize(productName)}`;
  }
  return `${sanitize(category)}_${sanitize(make)}_${sanitize(colour)}_${sanitize(thickness)}_${sanitize(gsm)}`;
};

export const fetchInventory = async (): Promise<InventoryItem[]> => {
  try {
    const snapshot = await getDocs(collection(db, 'inventory'));
    return snapshot.docs.map(d => ({ ...d.data(), id: d.id } as InventoryItem));
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'inventory');
    return [];
  }
};

export const resetAndUploadStock = async (items: InventoryItem[]) => {
  try {
    const currentItems = await getDocs(collection(db, 'inventory'));
    const now = new Date().toISOString();
    
    // 1. Clear old items in batches of 500
    const deleteBatches = [];
    let currentDeleteBatch = writeBatch(db);
    let deleteCount = 0;

    for (const d of currentItems.docs) {
      currentDeleteBatch.delete(d.ref);
      deleteCount++;
      if (deleteCount === 500) {
        deleteBatches.push(currentDeleteBatch.commit());
        currentDeleteBatch = writeBatch(db);
        deleteCount = 0;
      }
    }
    if (deleteCount > 0) deleteBatches.push(currentDeleteBatch.commit());
    await Promise.all(deleteBatches);

    // 2. Clear logs (optional based on requirement, usually we keep them but user asked for "reset and upload" often implies a fresh start)
    const logsSnap = await getDocs(collection(db, 'dispatch_logs'));
    let logBatch = writeBatch(db);
    let logCount = 0;
    for (const logDoc of logsSnap.docs) {
      logBatch.delete(logDoc.ref);
      logCount++;
      if (logCount === 500) {
        await logBatch.commit();
        logBatch = writeBatch(db);
        logCount = 0;
      }
    }
    if (logCount > 0) await logBatch.commit();

    // 3. Upload new items in batches of 500
    const uploadBatches = [];
    let currentUploadBatch = writeBatch(db);
    let uploadCount = 0;

    for (const item of items) {
      const id = getMaterialKey(item.make, item.colour, item.thickness, item.gsm, item.category, item.productName);
      const docRef = doc(db, 'inventory', id);
      
      const lowLimit = item.lowStockLimit || 500;
      let status: 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK' = 'IN_STOCK';
      if (item.remaining <= 0) status = 'OUT_OF_STOCK';
      else if (item.remaining <= lowLimit) status = 'LOW_STOCK';

      currentUploadBatch.set(docRef, {
        ...item,
        status,
        used: item.used || 0,
        dailyUsage: 0,
        estimatedDaysLeft: 999,
        updatedAt: now,
        createdAt: item.createdAt || now
      });
      
      uploadCount++;
      if (uploadCount === 500) {
        uploadBatches.push(currentUploadBatch.commit());
        currentUploadBatch = writeBatch(db);
        uploadCount = 0;
      }
    }
    if (uploadCount > 0) uploadBatches.push(currentUploadBatch.commit());
    await Promise.all(uploadBatches);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'inventory_reset_batch');
  }
};

export const handleStockDeduction = async (quotation: Quotation, dispatchId: string) => {
  try {
    const batch = writeBatch(db);
    const now = new Date().toISOString();
    
    // Multi-user safely fetching current state
    const snapshot = await getDocs(collection(db, 'inventory'));
    const inventoryMap = new Map(snapshot.docs.map(d => [d.id, d.data() as InventoryItem]));

    let deductionPerformed = false;

    for (const item of quotation.items) {
      // Find matching inventory item
      const materialKey = getMaterialKey(item.make, item.colour, item.thickness, item.gsm, item.category || 'GENERAL');
      const invData = inventoryMap.get(materialKey);

      if (invData) {
        deductionPerformed = true;
        let deductionQty = item.qty;
        
        // Convert to RFT if needed (JSW/Sheets logic)
        if (invData.unit === 'RFT') {
          if (item.unit === 'RMT') {
            deductionQty = item.qty * 3.28084;
          } else if (item.unit === 'SQFT' || item.unit === 'SQM') {
             const wid = item.wid || 3.5;
             let lenFt = item.unit === 'SQFT' ? (item.qty / wid) : (item.qty * 10.7639 / (wid * 3.28084));
             deductionQty = lenFt;
          }
        }

        const newRemaining = Math.max(0, invData.remaining - deductionQty);
        const newUsed = (invData.used || 0) + deductionQty;
        
        let updatePayload: any = {
          remaining: newRemaining,
          used: newUsed,
          updatedAt: now
        };

        // Custom JSW/Open Coil Logic
        if (invData.dispatchFrom === 'openCoilStock' && invData.openCoilStock !== undefined) {
          updatePayload.openCoilStock = Math.max(0, (invData.openCoilStock || 0) - deductionQty);
        }

        // Status logic
        let status: 'IN_STOCK' | 'LOW_STOCK' | 'OUT_OF_STOCK' = 'IN_STOCK';
        if (newRemaining <= 0) status = 'OUT_OF_STOCK';
        else if (newRemaining <= invData.lowStockLimit) status = 'LOW_STOCK';
        updatePayload.status = status;

        // Intelligence: Usage stats
        const startDate = new Date(invData.createdAt || invData.updatedAt);
        const daysSince = Math.max(1, (new Date().getTime() - startDate.getTime()) / (1000 * 3600 * 24));
        const dailyUsage = newUsed / daysSince;
        const daysLeft = dailyUsage > 0 ? newRemaining / dailyUsage : 999;
        updatePayload.dailyUsage = dailyUsage;
        updatePayload.estimatedDaysLeft = daysLeft;

        const invRef = doc(db, 'inventory', invData.id || materialKey);
        batch.update(invRef, updatePayload);

        // Log dispatch
        const logRef = doc(collection(db, 'dispatch_logs'));
        batch.set(logRef, {
          quotationId: quotation.id,
          dispatchId,
          materialKey,
          qtyDeducted: deductionQty,
          materialName: invData.productName,
          createdAt: now
        });
      }
    }

    if (deductionPerformed) {
      // Bonus: Update Quotation metrics
      let totalProfit = 0;
      quotation.items.forEach(p => {
        if (p.costPrice && p.costPrice > 0) {
          const profitPerUnit = (p.convertedRate || p.rate || 0) - p.costPrice;
          totalProfit += profitPerUnit * (p.qty || 0);
        }
      });

      const grandTotal = parseFloat((quotation.grandTotal || 0).toString().replace(/,/g, ''));
      const isHotDeal = grandTotal >= 100000;

      batch.update(doc(db, 'quotations', quotation.id!), {
        totalProfit,
        isHotDeal,
        isDeducted: true,
        updatedAt: now
      });
      await batch.commit();
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'stock_deduction');
  }
};

export const updateLowStockThreshold = async (materialKey: string, threshold: number) => {
  try {
    const docRef = doc(db, 'inventory', materialKey);
    await updateDoc(docRef, { lowStockThreshold: threshold });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `inventory/${materialKey}`);
  }
};
