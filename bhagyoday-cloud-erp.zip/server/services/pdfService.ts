import PDFDocument from 'pdfkit';
import fs from 'fs-extra';
import path from 'path';

export interface QuotationData {
  id?: string;
  custName: string;
  custPhone: string;
  estNo: string;
  date: string;
  items: any[];
  subTotal: number | string;
  taxAmount?: number | string;
  grandTotal: number | string;
  itemsCount: number;
}

export const generateQuotationPdf = async (data: QuotationData, outputPath: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({ margin: 50 });
      const stream = fs.createWriteStream(outputPath);

      doc.pipe(stream);

      // Header
      doc.fontSize(20).text('QUOTATION', { align: 'center', underline: true });
      doc.moveDown();

      // Basic Info
      doc.fontSize(12).text(`Estimate No: ${data.estNo}`);
      doc.text(`Date: ${data.date}`);
      doc.moveDown();

      doc.text(`Customer: ${data.custName}`);
      doc.text(`Phone: ${data.custPhone}`);
      doc.moveDown();

      // Table Header
      const tableTop = 200;
      doc.font('Helvetica-Bold');
      doc.text('Product', 50, tableTop);
      doc.text('Qty', 300, tableTop);
      doc.text('Rate', 350, tableTop);
      doc.text('Total', 450, tableTop);
      doc.font('Helvetica');

      // Table Row
      let currentHeight = tableTop + 25;
      data.items.forEach((item: any) => {
        doc.text(item.productName, 50, currentHeight);
        doc.text(item.qty.toString(), 300, currentHeight);
        doc.text(item.rate.toString(), 350, currentHeight);
        doc.text(item.total.toString(), 450, currentHeight);
        currentHeight += 20;
      });

      // Footer
      doc.moveDown();
      doc.fontSize(14).font('Helvetica-Bold').text(`Grand Total: ₹${data.grandTotal}`, { align: 'right' });

      doc.end();

      stream.on('finish', () => resolve(outputPath));
      stream.on('error', reject);
    } catch (error) {
      reject(error);
    }
  });
};
