import axios from 'axios';
import fs from 'fs-extra';
import FormData from 'form-data';

const WHATSAPP_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN;
const PHONE_NUMBER_ID = process.env.WHATSAPP_PHONE_NUMBER_ID;
const API_VERSION = process.env.WHATSAPP_API_VERSION || 'v20.0';

export const uploadMedia = async (filePath: string): Promise<string> => {
  if (!WHATSAPP_TOKEN || !PHONE_NUMBER_ID) {
    throw new Error('WhatsApp configuration missing');
  }

  const url = `https://graph.facebook.com/${API_VERSION}/${PHONE_NUMBER_ID}/media`;
  const form = new FormData();
  form.append('file', fs.createReadStream(filePath));
  form.append('type', 'application/pdf');
  form.append('messaging_product', 'whatsapp');

  const response = await axios.post(url, form, {
    headers: {
      ...form.getHeaders(),
      Authorization: `Bearer ${WHATSAPP_TOKEN}`,
    },
  });

  return response.data.id;
};

export const sendDocumentMessage = async (to: string, mediaId: string, filename: string): Promise<any> => {
  if (!WHATSAPP_TOKEN || !PHONE_NUMBER_ID) {
    throw new Error('WhatsApp configuration missing');
  }

  const url = `https://graph.facebook.com/${API_VERSION}/${PHONE_NUMBER_ID}/messages`;
  
  // Format phone number: remove any non-digits, ensure it has country code
  const formattedPhone = to.replace(/\D/g, '');

  const data = {
    messaging_product: 'whatsapp',
    recipient_type: 'individual',
    to: formattedPhone,
    type: 'document',
    document: {
      id: mediaId,
      filename: filename
    }
  };

  const response = await axios.post(url, data, {
    headers: {
      Authorization: `Bearer ${WHATSAPP_TOKEN}`,
      'Content-Type': 'application/json',
    },
  });

  return response.data;
};
