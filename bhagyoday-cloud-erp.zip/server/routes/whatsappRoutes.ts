import { Router } from 'express';
import { sendQuotation } from '../controllers/whatsappController';

const router = Router();

// POST /api/whatsapp/send-quotation
router.post('/send-quotation', sendQuotation);

export default router;
