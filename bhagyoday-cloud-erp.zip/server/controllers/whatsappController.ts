import { Request, Response } from 'express';
import path from 'path';
import fs from 'fs-extra';
import { generateQuotationPdf, QuotationData } from '../services/pdfService';
import { uploadMedia, sendDocumentMessage } from '../services/whatsappService';

export const sendQuotation = async (req: Request, res: Response) => {
  const { quotationData, phoneNumber } = req.body;
  const tempDir = path.join(process.cwd(), 'temp');
  const fileName = `Quotation_${quotationData.estNo || Date.now()}.pdf`;
  const filePath = path.join(tempDir, fileName);

  try {
    // 1. Ensure temp dir exists
    await fs.ensureDir(tempDir);

    // 2. Generate PDF
    console.log(`Generating PDF for ${quotationData.estNo}...`);
    await generateQuotationPdf(quotationData as QuotationData, filePath);

    // 3. Upload to WhatsApp Media API
    console.log(`Uploading to WhatsApp Media...`);
    const mediaId = await uploadMedia(filePath);

    // 4. Send Message
    console.log(`Sending WhatsApp message to ${phoneNumber}...`);
    const response = await sendDocumentMessage(phoneNumber, mediaId, fileName);

    // 5. Cleanup
    await fs.remove(filePath);

    res.status(200).json({
      success: true,
      message: 'Quotation sent successfully via WhatsApp',
      data: response
    });
  } catch (error: any) {
    console.error('WhatsApp Send Error:', error.response?.data || error.message);
    
    // Cleanup on error
    if (await fs.pathExists(filePath)) {
      await fs.remove(filePath);
    }

    res.status(500).json({
      success: false,
      message: 'Failed to send WhatsApp quotation',
      error: error.response?.data || error.message
    });
  }
};
